// Almacenamiento ligero en un archivo JSON (sin dependencias nativas, funciona en Termux/Android).
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

const EMPTY = () => ({ users: [], sessions: {}, games: [] });

let data = EMPTY();
let saveTimer = null;

function load() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    if (fs.existsSync(DB_FILE)) {
      data = { ...EMPTY(), ...JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) };
    }
  } catch (err) {
    console.error('[db] No se pudo leer la base de datos, se usará una vacía:', err.message);
    data = EMPTY();
  }
}

function saveNow() {
  try {
    const tmp = DB_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(data));
    fs.renameSync(tmp, DB_FILE);
  } catch (err) {
    console.error('[db] Error al guardar:', err.message);
  }
}

function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveNow, 250);
}

export function flush() {
  clearTimeout(saveTimer);
  saveNow();
}

// ---------- contraseñas ----------
export function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return { salt, hash };
}

export function verifyPassword(password, salt, hash) {
  const a = crypto.scryptSync(String(password), salt, 64);
  const b = Buffer.from(hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// ---------- usuarios ----------
const newStats = () => ({ games: 0, wins: 0, losses: 0, draws: 0 });

export function publicUser(u) {
  if (!u) return null;
  return {
    id: u.id,
    username: u.username,
    createdAt: u.createdAt,
    rating: u.rating,
    stats: u.stats,
    features: u.features || {},
    guest: false,
  };
}

export function findUserByName(username) {
  const lower = String(username || '').trim().toLowerCase();
  return data.users.find((u) => u.usernameLower === lower) || null;
}

export function findUserById(id) {
  return data.users.find((u) => u.id === id) || null;
}

export function validateCredentials(username, password) {
  const name = String(username || '').trim();
  if (!/^[A-Za-z0-9_]{3,20}$/.test(name)) {
    return 'El usuario debe tener 3–20 caracteres (letras, números o _).';
  }
  if (String(password || '').length < 4 || String(password).length > 100) {
    return 'La contraseña debe tener al menos 4 caracteres.';
  }
  return null;
}

export function createUser(username, password, extra = {}) {
  const name = String(username).trim();
  const { salt, hash } = hashPassword(password);
  const user = {
    id: crypto.randomUUID(),
    username: name,
    usernameLower: name.toLowerCase(),
    salt,
    hash,
    createdAt: Date.now(),
    rating: 1200,
    stats: newStats(),
    features: {},
    ...extra,
  };
  data.users.push(user);
  save();
  return user;
}

// ---------- sesiones ----------
export function createSession(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  data.sessions[token] = { userId, createdAt: Date.now() };
  save();
  return token;
}

export function getUserByToken(token) {
  if (!token || typeof token !== 'string') return null;
  const s = data.sessions[token];
  if (!s) return null;
  return findUserById(s.userId);
}

export function deleteSession(token) {
  if (data.sessions[token]) {
    delete data.sessions[token];
    save();
  }
}

// ---------- partidas ----------
function expected(a, b) {
  return 1 / (1 + Math.pow(10, (b - a) / 400));
}

/**
 * Guarda una partida terminada y actualiza estadísticas/rating de los jugadores registrados.
 * @param {{id:string, mode:string, white:{name:string,userId?:string|null}, black:{name:string,userId?:string|null}, result:string, reason:string, pgn:string, moves:number, timeControl:any}} game
 */
export function recordGame(game) {
  const record = { ...game, date: Date.now() };
  data.games.push(record);
  if (data.games.length > 5000) data.games.splice(0, data.games.length - 5000);

  const w = game.white.userId ? findUserById(game.white.userId) : null;
  const b = game.black.userId ? findUserById(game.black.userId) : null;
  const scoreW = game.result === '1-0' ? 1 : game.result === '0-1' ? 0 : 0.5;

  for (const [u, score] of [
    [w, scoreW],
    [b, 1 - scoreW],
  ]) {
    if (!u) continue;
    u.stats = u.stats || newStats();
    u.stats.games++;
    if (score === 1) u.stats.wins++;
    else if (score === 0) u.stats.losses++;
    else u.stats.draws++;
  }
  // Rating Elo sencillo sólo entre cuentas registradas distintas
  if (w && b && w.id !== b.id) {
    const ew = expected(w.rating, b.rating);
    const K = 32;
    w.rating = Math.round(w.rating + K * (scoreW - ew));
    b.rating = Math.round(b.rating + K * (1 - scoreW - (1 - ew)));
  }
  save();
  return record;
}

export function gamesForUser(userId, limit = 100) {
  return data.games
    .filter((g) => g.white.userId === userId || g.black.userId === userId)
    .slice(-limit)
    .reverse();
}

// ---------- inicialización ----------
export function init() {
  load();
  // Cuenta de demostración "Diego" con el panel privado Chess Assistant.
  let diego = findUserByName('Diego');
  if (!diego) {
    diego = createUser('Diego', '6727', { features: { assistant: true }, demo: true });
    console.log('[db] Cuenta de demostración creada: Diego');
  } else if (!diego.features?.assistant) {
    diego.features = { ...(diego.features || {}), assistant: true };
    save();
  }
}
