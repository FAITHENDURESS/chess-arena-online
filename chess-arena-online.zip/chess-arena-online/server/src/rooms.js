// Gestión de salas y partidas en tiempo real (online y LAN). El servidor es la autoridad:
// valida cada jugada con chess.js y lleva los relojes.
import crypto from 'node:crypto';
import { Chess } from 'chess.js';
import * as db from './db.js';

const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const DISCONNECT_FORFEIT_MS = 60_000; // abandono tras 60 s desconectado durante la partida
const WAITING_ROOM_TTL_MS = 3 * 60_000; // sala en espera sin anfitrión conectado
const ENDED_ROOM_TTL_MS = 30 * 60_000;

/** @type {Map<string, any>} */
const rooms = new Map();
/** @type {Map<string, string>} code -> roomId */
const byCode = new Map();

let io = null;

function makeCode() {
  let code;
  do {
    code = Array.from(crypto.randomBytes(6), (b) => CODE_ALPHABET[b % CODE_ALPHABET.length]).join('');
  } while (byCode.has(code));
  return code;
}

const other = (c) => (c === 'w' ? 'b' : 'w');
const sanitize = (s, max = 40) => String(s ?? '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, max);

function parseTimeControl(tc) {
  if (!tc || !Number(tc.minutes)) return null;
  const minutes = Math.min(180, Math.max(0.5, Number(tc.minutes)));
  const increment = Math.min(60, Math.max(0, Number(tc.increment) || 0));
  return { minutes, increment, initial: Math.round(minutes * 60_000), inc: increment * 1000 };
}

function publicPlayer(p) {
  if (!p) return null;
  return {
    name: p.name,
    guest: !p.userId,
    rating: p.userId ? db.findUserById(p.userId)?.rating ?? null : null,
    connected: p.connected,
  };
}

function seatOf(room, clientId) {
  if (room.seats.w?.clientId === clientId) return 'w';
  if (room.seats.b?.clientId === clientId) return 'b';
  return null;
}

function snapshot(room, clientId) {
  const ch = room.chess;
  const hist = ch.history({ verbose: true });
  const last = hist[hist.length - 1];
  const turn = ch.turn();
  return {
    id: room.id,
    code: room.code,
    mode: room.mode,
    visibility: room.visibility,
    timeControl: room.timeControl ? { minutes: room.timeControl.minutes, increment: room.timeControl.increment } : null,
    status: room.status,
    gameNumber: room.gameNumber,
    fen: ch.fen(),
    pgn: room.status === 'ended' ? buildPgn(room) : '',
    moves: hist.map((m) => ({ san: m.san, from: m.from, to: m.to })),
    lastMove: last ? { from: last.from, to: last.to } : null,
    turn,
    inCheck: ch.inCheck(),
    players: { w: publicPlayer(room.seats.w), b: publicPlayer(room.seats.b) },
    clock: room.timeControl
      ? {
          w: room.clock.w,
          b: room.clock.b,
          running: room.status === 'playing' && room.clock.turnStart ? turn : null,
          turnStart: room.clock.turnStart,
        }
      : null,
    serverNow: Date.now(),
    result: room.result,
    reason: room.reason,
    chat: room.chat.slice(-100),
    drawOffer: room.drawOffer,
    rematch: room.rematch,
    spectators: room.spectators.size,
    you: seatOf(room, clientId) || 'spectator',
    disconnectDeadline: room.disconnectDeadline,
  };
}

function buildPgn(room) {
  const c = new Chess();
  for (const m of room.chess.history()) c.move(m);
  const d = new Date(room.startedAt || Date.now());
  c.setHeader('Event', room.mode === 'lan' ? 'Chess Arena Online (LAN)' : 'Chess Arena Online');
  c.setHeader('Site', 'Chess Arena Online');
  c.setHeader('Date', `${d.getFullYear()}.${String(d.getMonth() + 1).padStart(2, '0')}.${String(d.getDate()).padStart(2, '0')}`);
  c.setHeader('White', room.seats.w?.name || '?');
  c.setHeader('Black', room.seats.b?.name || '?');
  c.setHeader('Result', room.result || '*');
  if (room.timeControl) c.setHeader('TimeControl', `${room.timeControl.initial / 1000}+${room.timeControl.increment}`);
  if (room.reason) c.setHeader('Termination', room.reason);
  return c.pgn();
}

function broadcast(room) {
  if (!io) return;
  const sids = io.sockets.adapter.rooms.get(room.id);
  if (!sids) return;
  for (const sid of sids) {
    const s = io.sockets.sockets.get(sid);
    if (s) s.emit('room:state', snapshot(room, s.data.clientId));
  }
}

function lobbyList(mode) {
  const out = [];
  for (const r of rooms.values()) {
    if (r.mode !== mode || r.visibility !== 'public' || r.status !== 'waiting') continue;
    const host = r.seats.w || r.seats.b;
    if (!host?.connected) continue;
    out.push({
      id: r.id,
      code: r.code,
      host: host.name,
      hostRating: publicPlayer(host).rating,
      hostColor: r.seats.w ? 'w' : 'b',
      timeControl: r.timeControl ? { minutes: r.timeControl.minutes, increment: r.timeControl.increment } : null,
      createdAt: r.createdAt,
    });
  }
  return out.sort((a, b) => b.createdAt - a.createdAt);
}

function broadcastLobby(mode) {
  io?.to(`lobby:${mode}`).emit('lobby:rooms', { mode, rooms: lobbyList(mode) });
}

export function listRooms(mode) {
  return lobbyList(mode);
}

export function roomCount() {
  let n = 0;
  for (const r of rooms.values()) if (r.status !== 'ended') n++;
  return n;
}

function deleteRoom(room) {
  clearTimeout(room.timer);
  clearTimeout(room.cleanupTimer);
  for (const t of Object.values(room.dcTimers)) clearTimeout(t);
  rooms.delete(room.id);
  byCode.delete(room.code);
  broadcastLobby(room.mode);
}

function scheduleCleanup(room, ms) {
  clearTimeout(room.cleanupTimer);
  room.cleanupTimer = setTimeout(() => deleteRoom(room), ms);
  room.cleanupTimer.unref?.();
}

// ---------- relojes ----------
function scheduleFlag(room) {
  clearTimeout(room.timer);
  if (room.status !== 'playing' || !room.timeControl || !room.clock.turnStart) return;
  const turn = room.chess.turn();
  const remaining = room.clock[turn] - (Date.now() - room.clock.turnStart);
  room.timer = setTimeout(() => checkFlag(room), Math.max(0, remaining) + 30);
}

function checkFlag(room) {
  if (room.status !== 'playing' || !room.timeControl || !room.clock.turnStart) return;
  const turn = room.chess.turn();
  const remaining = room.clock[turn] - (Date.now() - room.clock.turnStart);
  if (remaining > 0) return scheduleFlag(room);
  room.clock[turn] = 0;
  room.clock.turnStart = null;
  // Si el rival no tiene material para dar mate, son tablas.
  const opp = other(turn);
  const oppPieces = room.chess.board().flat().filter((p) => p && p.color === opp && p.type !== 'k');
  const minors = oppPieces.filter((p) => p.type === 'b' || p.type === 'n').length;
  const hasMating = oppPieces.some((p) => p.type === 'q' || p.type === 'r' || p.type === 'p') || minors >= 2;
  if (!hasMating) endGame(room, '1/2-1/2', 'Tiempo agotado vs. material insuficiente');
  else endGame(room, opp === 'w' ? '1-0' : '0-1', 'Tiempo agotado');
}

// ---------- ciclo de partida ----------
function startGame(room) {
  room.status = 'playing';
  room.startedAt = Date.now();
  room.result = null;
  room.reason = null;
  room.drawOffer = null;
  room.rematch = { w: false, b: false };
  if (room.timeControl) room.clock = { w: room.timeControl.initial, b: room.timeControl.initial, turnStart: null };
  clearTimeout(room.cleanupTimer);
  room.chat.push({ system: true, text: `Comienza la partida: ${room.seats.w.name} (blancas) vs ${room.seats.b.name} (negras)`, ts: Date.now() });
  broadcastLobby(room.mode);
}

function endGame(room, result, reason) {
  if (room.status === 'ended') return;
  if (room.status === 'playing' && room.timeControl && room.clock.turnStart) {
    const turn = room.chess.turn();
    room.clock[turn] = Math.max(0, room.clock[turn] - (Date.now() - room.clock.turnStart));
  }
  if (room.clock) room.clock.turnStart = null;
  clearTimeout(room.timer);
  for (const t of Object.values(room.dcTimers)) clearTimeout(t);
  room.dcTimers = {};
  room.disconnectDeadline = null;
  room.status = 'ended';
  room.result = result;
  room.reason = reason;
  room.drawOffer = null;
  room.chat.push({ system: true, text: `Fin de la partida: ${result} — ${reason}`, ts: Date.now() });
  const moves = room.chess.history().length;
  if (room.seats.w?.userId || room.seats.b?.userId) {
    db.recordGame({
      id: `${room.id}-${room.gameNumber}`,
      mode: room.mode,
      white: { name: room.seats.w?.name, userId: room.seats.w?.userId || null },
      black: { name: room.seats.b?.name, userId: room.seats.b?.userId || null },
      result,
      reason,
      pgn: buildPgn(room),
      moves,
      timeControl: room.timeControl ? { minutes: room.timeControl.minutes, increment: room.timeControl.increment } : null,
    });
  }
  scheduleCleanup(room, ENDED_ROOM_TTL_MS);
  broadcast(room);
}

function afterMoveChecks(room) {
  const ch = room.chess;
  const mover = other(ch.turn());
  if (ch.isCheckmate()) return endGame(room, mover === 'w' ? '1-0' : '0-1', 'Jaque mate');
  if (ch.isStalemate()) return endGame(room, '1/2-1/2', 'Rey ahogado');
  if (ch.isInsufficientMaterial()) return endGame(room, '1/2-1/2', 'Material insuficiente');
  if (ch.isThreefoldRepetition()) return endGame(room, '1/2-1/2', 'Triple repetición');
  if (ch.isDrawByFiftyMoves()) return endGame(room, '1/2-1/2', 'Regla de los 50 movimientos');
}

// ---------- handlers ----------
function identity(socket) {
  const auth = socket.handshake.auth || {};
  const user = db.getUserByToken(auth.token);
  const clientId = sanitize(auth.clientId, 64) || crypto.randomUUID();
  socket.data.clientId = clientId;
  socket.data.userId = user?.id || null;
  socket.data.name = user ? user.username : sanitize(auth.name, 24) || `Invitado-${clientId.slice(0, 4)}`;
  socket.data.rooms = new Set();
}

function attach(socket, room) {
  socket.join(room.id);
  socket.data.rooms.add(room.id);
  const seat = seatOf(room, socket.data.clientId);
  if (seat) {
    const p = room.seats[seat];
    p.socketId = socket.id;
    p.connected = true;
    clearTimeout(room.dcTimers[seat]);
    delete room.dcTimers[seat];
    if (!room.dcTimers.w && !room.dcTimers.b) room.disconnectDeadline = null;
    if (room.status === 'waiting') clearTimeout(room.cleanupTimer);
  } else {
    room.spectators.set(socket.data.clientId, { name: socket.data.name, socketId: socket.id });
  }
}

function makePlayer(socket) {
  return {
    clientId: socket.data.clientId,
    name: socket.data.name,
    userId: socket.data.userId,
    socketId: socket.id,
    connected: true,
  };
}

function handleDisconnectFromRoom(socket, room) {
  room.spectators.delete(socket.data.clientId);
  const seat = seatOf(room, socket.data.clientId);
  if (!seat) return broadcast(room);
  const p = room.seats[seat];
  if (p.socketId !== socket.id) return; // ya reconectado en otro socket
  p.connected = false;
  p.socketId = null;
  if (room.status === 'playing') {
    clearTimeout(room.dcTimers[seat]);
    room.disconnectDeadline = Date.now() + DISCONNECT_FORFEIT_MS;
    room.chat.push({ system: true, text: `${p.name} se desconectó. Tiene 60 s para volver.`, ts: Date.now() });
    room.dcTimers[seat] = setTimeout(() => {
      if (room.seats[seat] && !room.seats[seat].connected && room.status === 'playing') {
        endGame(room, seat === 'w' ? '0-1' : '1-0', 'Abandono por desconexión');
      }
    }, DISCONNECT_FORFEIT_MS);
  } else if (room.status === 'waiting') {
    scheduleCleanup(room, WAITING_ROOM_TTL_MS);
    broadcastLobby(room.mode);
  }
  broadcast(room);
}

export function setupRooms(ioServer) {
  io = ioServer;

  io.on('connection', (socket) => {
    identity(socket);

    socket.on('lobby:subscribe', ({ mode } = {}) => {
      const m = mode === 'lan' ? 'lan' : 'online';
      socket.leave('lobby:online');
      socket.leave('lobby:lan');
      socket.join(`lobby:${m}`);
      socket.emit('lobby:rooms', { mode: m, rooms: lobbyList(m) });
    });
    socket.on('lobby:unsubscribe', () => {
      socket.leave('lobby:online');
      socket.leave('lobby:lan');
    });

    socket.on('room:create', (opts = {}, ack = () => {}) => {
      const mode = opts.mode === 'lan' ? 'lan' : 'online';
      let color = opts.color === 'w' || opts.color === 'b' ? opts.color : Math.random() < 0.5 ? 'w' : 'b';
      const room = {
        id: crypto.randomUUID(),
        code: makeCode(),
        mode,
        visibility: opts.visibility === 'private' ? 'private' : 'public',
        timeControl: parseTimeControl(opts.timeControl),
        createdAt: Date.now(),
        status: 'waiting',
        gameNumber: 1,
        chess: new Chess(),
        seats: { w: null, b: null },
        spectators: new Map(),
        clock: { w: 0, b: 0, turnStart: null },
        result: null,
        reason: null,
        chat: [],
        drawOffer: null,
        rematch: { w: false, b: false },
        timer: null,
        cleanupTimer: null,
        dcTimers: {},
        disconnectDeadline: null,
      };
      room.seats[color] = makePlayer(socket);
      rooms.set(room.id, room);
      byCode.set(room.code, room.id);
      attach(socket, room);
      ack({ ok: true, roomId: room.id, code: room.code });
      broadcast(room);
      broadcastLobby(mode);
    });

    socket.on('room:join', ({ code, roomId } = {}, ack = () => {}) => {
      const id = roomId || byCode.get(String(code || '').trim().toUpperCase());
      const room = id && rooms.get(id);
      if (!room) return ack({ ok: false, error: 'Sala no encontrada. Revisa el código.' });
      const seat = seatOf(room, socket.data.clientId);
      if (!seat && room.status === 'waiting') {
        const free = !room.seats.w ? 'w' : !room.seats.b ? 'b' : null;
        if (free) {
          room.seats[free] = makePlayer(socket);
          attach(socket, room);
          startGame(room);
          ack({ ok: true, roomId: room.id, mode: room.mode, role: free });
          return broadcast(room);
        }
      }
      attach(socket, room);
      ack({ ok: true, roomId: room.id, mode: room.mode, role: seat || 'spectator' });
      broadcast(room);
    });

    socket.on('room:leave', ({ roomId } = {}) => {
      const room = rooms.get(roomId);
      if (!room) return;
      socket.leave(room.id);
      socket.data.rooms.delete(room.id);
      const seat = seatOf(room, socket.data.clientId);
      if (room.status === 'waiting' && seat) return deleteRoom(room);
      handleDisconnectFromRoom(socket, room);
    });

    socket.on('game:move', ({ roomId, from, to, promotion } = {}, ack = () => {}) => {
      const room = rooms.get(roomId);
      if (!room || room.status !== 'playing') return ack({ ok: false, error: 'La partida no está en curso.' });
      const seat = seatOf(room, socket.data.clientId);
      const turn = room.chess.turn();
      if (seat !== turn) return ack({ ok: false, error: 'No es tu turno.' });
      const now = Date.now();
      if (room.timeControl && room.clock.turnStart) {
        const left = room.clock[turn] - (now - room.clock.turnStart);
        if (left <= 0) {
          checkFlag(room);
          return ack({ ok: false, error: 'Tiempo agotado.' });
        }
      }
      let move;
      try {
        move = room.chess.move({ from, to, promotion: promotion || undefined });
      } catch {
        move = null;
      }
      if (!move) return ack({ ok: false, error: 'Movimiento ilegal.' });
      if (room.timeControl) {
        if (room.clock.turnStart) {
          room.clock[turn] = room.clock[turn] - (now - room.clock.turnStart) + room.timeControl.inc;
        }
        // El reloj arranca después de la primera jugada de las blancas.
        room.clock.turnStart = now;
      }
      room.drawOffer = null;
      ack({ ok: true });
      afterMoveChecks(room);
      if (room.status === 'playing') {
        scheduleFlag(room);
        broadcast(room);
      }
    });

    socket.on('game:resign', ({ roomId } = {}) => {
      const room = rooms.get(roomId);
      const seat = room && seatOf(room, socket.data.clientId);
      if (!room || !seat || room.status !== 'playing') return;
      endGame(room, seat === 'w' ? '0-1' : '1-0', `${room.seats[seat].name} abandonó`);
    });

    socket.on('game:draw', ({ roomId, action } = {}) => {
      const room = rooms.get(roomId);
      const seat = room && seatOf(room, socket.data.clientId);
      if (!room || !seat || room.status !== 'playing') return;
      if (action === 'offer' && !room.drawOffer) {
        room.drawOffer = seat;
        room.chat.push({ system: true, text: `${room.seats[seat].name} ofrece tablas.`, ts: Date.now() });
      } else if (action === 'accept' && room.drawOffer === other(seat)) {
        return endGame(room, '1/2-1/2', 'Tablas por acuerdo');
      } else if (action === 'decline' && room.drawOffer === other(seat)) {
        room.drawOffer = null;
        room.chat.push({ system: true, text: `${room.seats[seat].name} rechazó las tablas.`, ts: Date.now() });
      }
      broadcast(room);
    });

    socket.on('game:rematch', ({ roomId } = {}) => {
      const room = rooms.get(roomId);
      const seat = room && seatOf(room, socket.data.clientId);
      if (!room || !seat || room.status !== 'ended') return;
      room.rematch[seat] = true;
      if (room.rematch.w && room.rematch.b && room.seats.w && room.seats.b) {
        // Nueva partida con colores invertidos
        const w = room.seats.w;
        room.seats.w = room.seats.b;
        room.seats.b = w;
        room.chess = new Chess();
        room.gameNumber++;
        startGame(room);
      } else {
        room.chat.push({ system: true, text: `${room.seats[seat].name} quiere la revancha.`, ts: Date.now() });
      }
      broadcast(room);
    });

    socket.on('chat:send', ({ roomId, text } = {}) => {
      const room = rooms.get(roomId);
      if (!room || !socket.data.rooms.has(roomId)) return;
      const clean = sanitize(text, 300);
      if (!clean) return;
      const seat = seatOf(room, socket.data.clientId);
      room.chat.push({ name: socket.data.name, color: seat, text: clean, ts: Date.now() });
      if (room.chat.length > 200) room.chat.splice(0, room.chat.length - 200);
      broadcast(room);
    });

    socket.on('time:sync', (_ = {}, ack = () => {}) => ack({ serverNow: Date.now() }));

    socket.on('disconnect', () => {
      for (const id of socket.data.rooms) {
        const room = rooms.get(id);
        if (room) handleDisconnectFromRoom(socket, room);
      }
    });
  });
}
