// Descubrimiento de anfitriones en la red local (Wi‑Fi o punto de acceso del celular).
// Usa dos mecanismos, ambos sin Internet:
//   1) Balizas UDP broadcast (puerto 41234).
//   2) mDNS / Bonjour (servicio _chess-arena._tcp), si el sistema lo permite.
import dgram from 'node:dgram';
import os from 'node:os';
import crypto from 'node:crypto';

const DISCOVERY_PORT = Number(process.env.DISCOVERY_PORT || 41234);
const APP_ID = 'chess-arena-online';

function isPrivateIPv4(ip) {
  return (
    /^10\./.test(ip) ||
    /^192\.168\./.test(ip) ||
    /^172\.(1[6-9]|2\d|3[01])\./.test(ip) ||
    /^169\.254\./.test(ip)
  );
}

/** Direcciones IPv4 locales (no loopback), las privadas primero. */
export function getLanAddresses() {
  const out = [];
  for (const [ifname, list] of Object.entries(os.networkInterfaces())) {
    for (const a of list || []) {
      const fam = typeof a.family === 'string' ? a.family : a.family === 4 ? 'IPv4' : 'IPv6';
      if (fam !== 'IPv4' || a.internal) continue;
      out.push({ ifname, address: a.address, netmask: a.netmask });
    }
  }
  out.sort((a, b) => Number(isPrivateIPv4(b.address)) - Number(isPrivateIPv4(a.address)));
  return out;
}

function broadcastAddress(ip, mask) {
  const i = ip.split('.').map(Number);
  const m = mask.split('.').map(Number);
  return i.map((v, k) => (v | (~m[k] & 255)) >>> 0).join('.');
}

/**
 * @param {{port:number, name:string, getRoomCount:()=>number}} opts
 */
export function startLanDiscovery({ port, name, getRoomCount }) {
  const selfId = crypto.randomBytes(6).toString('hex');
  /** @type {Map<string, {id:string,name:string,ip:string,port:number,rooms:number,via:string,lastSeen:number}>} */
  const peers = new Map();
  const status = { udp: false, mdns: false };

  // ---------- UDP ----------
  let sock;
  try {
    sock = dgram.createSocket({ type: 'udp4', reuseAddr: true });
    sock.on('error', (err) => {
      console.warn('[lan] UDP no disponible:', err.message);
      status.udp = false;
      try { sock.close(); } catch { /* ignore */ }
    });
    sock.on('message', (msg, rinfo) => {
      try {
        const m = JSON.parse(msg.toString());
        if (m.app !== APP_ID || m.id === selfId) return;
        const key = `${rinfo.address}:${m.port}`;
        peers.set(key, {
          id: m.id,
          name: String(m.name || 'Anfitrión').slice(0, 40),
          ip: rinfo.address,
          port: Number(m.port),
          rooms: Number(m.rooms) || 0,
          via: 'udp',
          lastSeen: Date.now(),
        });
      } catch { /* paquete ajeno */ }
    });
    sock.bind(DISCOVERY_PORT, () => {
      try {
        sock.setBroadcast(true);
        status.udp = true;
      } catch (e) {
        console.warn('[lan] Broadcast no permitido:', e.message);
      }
      const beacon = () => {
        if (!status.udp) return;
        const payload = Buffer.from(
          JSON.stringify({ app: APP_ID, id: selfId, name, port, rooms: getRoomCount() })
        );
        const targets = new Set(['255.255.255.255']);
        for (const a of getLanAddresses()) targets.add(broadcastAddress(a.address, a.netmask));
        for (const t of targets) sock.send(payload, DISCOVERY_PORT, t, () => {});
      };
      beacon();
      setInterval(beacon, 3000).unref();
    });
  } catch (err) {
    console.warn('[lan] No se pudo iniciar UDP:', err.message);
  }

  // ---------- mDNS ----------
  (async () => {
    try {
      const { Bonjour } = await import('bonjour-service');
      const bonjour = new Bonjour();
      bonjour.publish({ name: `${name} (${selfId})`, type: 'chess-arena', port, txt: { id: selfId } });
      const browser = bonjour.find({ type: 'chess-arena' });
      browser.on('up', (svc) => {
        if (svc.txt?.id === selfId) return;
        const ip = (svc.addresses || []).find((a) => /^\d+\.\d+\.\d+\.\d+$/.test(a));
        if (!ip) return;
        peers.set(`${ip}:${svc.port}`, {
          id: svc.txt?.id || svc.name,
          name: String(svc.name).replace(/\s*\([0-9a-f]+\)$/, ''),
          ip,
          port: svc.port,
          rooms: 0,
          via: 'mdns',
          lastSeen: Date.now() + 60_000 * 60, // vigente mientras esté anunciado
        });
      });
      browser.on('down', (svc) => {
        for (const [k, p] of peers) if (p.via === 'mdns' && p.id === (svc.txt?.id || svc.name)) peers.delete(k);
      });
      status.mdns = true;
      process.on('exit', () => { try { bonjour.unpublishAll(); bonjour.destroy(); } catch { /* ignore */ } });
    } catch (err) {
      console.warn('[lan] mDNS no disponible:', err.message);
    }
  })();

  return {
    status,
    getPeers() {
      const now = Date.now();
      const list = [];
      for (const [k, p] of peers) {
        if (now - p.lastSeen > 12_000 && p.via === 'udp') {
          peers.delete(k);
          continue;
        }
        list.push({ name: p.name, ip: p.ip, port: p.port, rooms: p.rooms, via: p.via, url: `http://${p.ip}:${p.port}` });
      }
      return list;
    },
  };
}
