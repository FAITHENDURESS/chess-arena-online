// Chess Arena Online — servidor principal.
// Sirve la aplicación web, la API REST de cuentas/historial y Socket.IO para partidas online y LAN.
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { Server } from 'socket.io';
import * as db from './db.js';
import { setupRooms, listRooms, roomCount } from './rooms.js';
import { startLanDiscovery, getLanAddresses } from './lan.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const HOST_NAME = (process.env.HOST_NAME || os.hostname() || 'Anfitrión').slice(0, 40);
const CLIENT_DIST = process.env.CLIENT_DIST || path.join(__dirname, '..', '..', 'client', 'dist');

db.init();

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '200kb' }));

// CORS sencillo para que un cliente servido desde otro origen (p. ej. el servidor LAN) use un servidor online.
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Vary', 'Origin');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

function auth(req) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  return { token, user: db.getUserByToken(token) };
}

// Límite básico de intentos de inicio de sesión por IP.
const attempts = new Map();
function rateLimited(ip) {
  const now = Date.now();
  const a = attempts.get(ip) || { n: 0, t: now };
  if (now - a.t > 60_000) { a.n = 0; a.t = now; }
  a.n++;
  attempts.set(ip, a);
  return a.n > 20;
}

app.get('/api/ping', (_req, res) => res.json({ ok: true, app: 'chess-arena-online', name: HOST_NAME, time: Date.now() }));

app.post('/api/register', (req, res) => {
  if (rateLimited(req.ip)) return res.status(429).json({ error: 'Demasiados intentos. Espera un minuto.' });
  const { username, password } = req.body || {};
  const err = db.validateCredentials(username, password);
  if (err) return res.status(400).json({ error: err });
  if (db.findUserByName(username)) return res.status(409).json({ error: 'Ese nombre de usuario ya existe.' });
  const user = db.createUser(username, password);
  const token = db.createSession(user.id);
  res.json({ token, user: db.publicUser(user) });
});

app.post('/api/login', (req, res) => {
  if (rateLimited(req.ip)) return res.status(429).json({ error: 'Demasiados intentos. Espera un minuto.' });
  const { username, password } = req.body || {};
  const user = db.findUserByName(username);
  if (!user || !db.verifyPassword(password, user.salt, user.hash)) {
    return res.status(401).json({ error: 'Usuario o contraseña incorrectos.' });
  }
  const token = db.createSession(user.id);
  res.json({ token, user: db.publicUser(user) });
});

app.post('/api/logout', (req, res) => {
  const { token } = auth(req);
  if (token) db.deleteSession(token);
  res.json({ ok: true });
});

app.get('/api/me', (req, res) => {
  const { user } = auth(req);
  if (!user) return res.status(401).json({ error: 'Sesión no válida.' });
  res.json({ user: db.publicUser(user) });
});

app.get('/api/games', (req, res) => {
  const { user } = auth(req);
  if (!user) return res.status(401).json({ error: 'Inicia sesión para ver tu historial del servidor.' });
  res.json({ games: db.gamesForUser(user.id) });
});

app.get('/api/rooms', (req, res) => {
  res.json({ rooms: listRooms(req.query.mode === 'lan' ? 'lan' : 'online') });
});

let lan = null;
app.get('/api/lan/info', (_req, res) => {
  const ips = getLanAddresses().map((a) => a.address);
  res.json({
    name: HOST_NAME,
    port: PORT,
    ips,
    urls: ips.map((ip) => `http://${ip}:${PORT}`),
    discovery: lan ? lan.status : { udp: false, mdns: false },
    peers: lan ? lan.getPeers() : [],
    rooms: roomCount(),
  });
});

// Aplicación web compilada
if (fs.existsSync(CLIENT_DIST)) {
  app.use(express.static(CLIENT_DIST, {
    setHeaders(res, file) {
      if (file.endsWith('index.html') || file.endsWith('sw.js')) res.setHeader('Cache-Control', 'no-cache');
    },
  }));
  app.get(/^\/(?!api\/|socket\.io\/).*/, (_req, res) => res.sendFile(path.join(CLIENT_DIST, 'index.html')));
} else {
  app.get('/', (_req, res) =>
    res.type('text').send('Cliente no compilado. Ejecuta "npm run build" en la carpeta raíz del proyecto.')
  );
}

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: true, credentials: false },
  pingInterval: 10_000,
  pingTimeout: 8_000,
});
setupRooms(io);

server.listen(PORT, HOST, () => {
  lan = startLanDiscovery({ port: PORT, name: HOST_NAME, getRoomCount: roomCount });
  console.log('\n♟  Chess Arena Online en marcha');
  console.log(`   Local:      http://localhost:${PORT}`);
  for (const a of getLanAddresses()) console.log(`   Red local:  http://${a.address}:${PORT}   (${a.ifname})`);
  console.log('   Comparte la dirección de "Red local" con los dispositivos de tu Wi‑Fi o punto de acceso.\n');
});

function shutdown() {
  db.flush();
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
