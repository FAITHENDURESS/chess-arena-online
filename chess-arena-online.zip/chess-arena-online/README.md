# ♟️ Chess Arena Online

Aplicación de ajedrez completa: **partidas online**, **partidas por Wi‑Fi local sin Internet (LAN)**, **contra la computadora (Stockfish)**, **2 jugadores en un mismo dispositivo**, **modo invitado**, cuentas, historial y la cuenta de demostración **Diego** con su panel privado **Chess Assistant**.

- Interfaz: React + TypeScript (Vite), tablero y piezas SVG propios, tema oscuro, responsive (Android y PC).
- Reglas: chess.js (jugada legal, jaque, mate, enroques, captura al paso, promoción, ahogado, triple repetición, 50 movimientos, material insuficiente, SAN).
- Motor: Stockfish 17.1 (WASM, se ejecuta en el propio navegador, también sin Internet).
- Tiempo real: Node.js + Express + Socket.IO. Base de datos: archivo JSON (sin dependencias nativas, funciona en Termux/Android).

---

## 1. Inicio rápido (PC con Windows, macOS o Linux)

Requisito: **Node.js 18 o superior** (https://nodejs.org).

```bash
cd chess-arena-online
npm run setup:server     # instala sólo las dependencias del servidor
npm start                # arranca en el puerto 3000
```

El ZIP ya incluye la app compilada (`client/dist`), así que **no hace falta compilar** para jugar. Abre `http://localhost:3000`.

En la consola verás también la dirección para el resto de dispositivos, por ejemplo:

```
Red local:  http://192.168.1.35:3000
```

### Cuenta de demostración

| Usuario | Contraseña |
|---------|------------|
| `Diego` | `6727`     |

Se crea automáticamente la primera vez que arranca el servidor. Al iniciar sesión con ella aparece el panel **Chess Assistant** (sólo en esa sesión): análisis Stockfish de la posición actual, las mejores jugadas (pieza, casilla de origen y destino, notación SAN), evaluación con barra, profundidad configurable (6–24), 1–3 recomendaciones, flechas en el tablero, análisis automático o bajo demanda. El panel se calcula en el propio dispositivo de Diego: no se envía nada al servidor y el rival no ve ningún indicador.

---

## 2. Jugar por Wi‑Fi local SIN Internet

Los navegadores de los celulares **no pueden** usar UDP ni mDNS, así que la app funciona así:

1. **Un dispositivo hace de anfitrión** y ejecuta el servidor (`npm start`): un PC/portátil o un celular Android con Termux (ver abajo).
2. Los demás dispositivos se conectan a la **misma red Wi‑Fi** o al **punto de acceso** del anfitrión y abren la dirección `http://IP-DEL-ANFITRION:3000` (aparece en la consola y en la pantalla **Jugar por Wi‑Fi local** con un **código QR**).
3. En **Jugar por Wi‑Fi local**: uno crea la sala; el otro la ve en la lista de *Salas disponibles en la red* o entra con el **código de sala** o escaneando el **QR** de invitación.

Qué incluye la parte LAN:

- **Descubrimiento automático** entre anfitriones mediante **balizas UDP** (puerto 41234) y **mDNS/Bonjour** (`_chess-arena._tcp`). Lo hace el servidor (sí puede usar UDP), y la app muestra los *Otros anfitriones encontrados en la red*.
- Conexión por **IP local** (campo *Conectar por IP*), **código de sala** y **código QR**.
- Jugadas sincronizadas y validadas por el anfitrión, **relojes sincronizados** (el reloj lo lleva el servidor), elección de color, **desconexión y reconexión** (60 s de margen antes de perder por abandono), chat y espectadores.
- No depende de ningún servidor externo.

### Anfitrión en un celular Android (Termux)

1. Instala **Termux** desde F‑Droid.
2. En Termux:
   ```bash
   pkg update && pkg install nodejs unzip
   termux-setup-storage            # permite leer Descargas
   cp ~/storage/downloads/chess-arena-online.zip ~ && cd ~ && unzip chess-arena-online.zip
   cd chess-arena-online
   npm run setup:server
   npm start
   ```
3. Activa el **punto de acceso** de ese celular (o conéctalo al Wi‑Fi). La IP del punto de acceso suele ser `192.168.43.1` o similar; el servidor la imprime al arrancar.
4. El propio anfitrión también juega abriendo `http://localhost:3000` en Chrome.

> Consejo: en algunos Android el punto de acceso aísla a los clientes o bloquea el broadcast UDP. Si la lista de salas automática no aparece, usa siempre la **IP + código de sala** o el **QR**: funcionan igual.

### Instalar como app

Desde Chrome, menú ⋮ → *Añadir a pantalla de inicio*. (La instalación completa como PWA con modo sin conexión requiere `https` o `localhost`; en LAN por `http://IP` se abre igualmente como acceso directo.)

---

## 3. Jugar online (por Internet)

El mismo servidor sirve para Internet. Despliégalo en cualquier servicio con Node.js (Render, Railway, Fly.io, un VPS…):

- **Comando de compilación:** `npm run setup:server`
- **Comando de inicio:** `npm start`
- Variables opcionales: `PORT` (la asigna el servicio), `DATA_DIR` (carpeta de la base de datos; usa un disco persistente para no perder cuentas).

Después comparte la URL pública. Funciones online: crear partida pública o **privada**, **invitar por enlace, código o QR** (`https://tu-servidor/?join=CÓDIGO`), **buscar partidas** (lista en vivo con búsqueda), unirse, elegir blancas/negras/aleatorio, **chat**, **relojes** con incremento, **ofrecer tablas**, abandonar, **revancha** con colores invertidos y **reconexión** automática.

Si la app se abre desde otro sitio (por ejemplo desde un anfitrión LAN) puedes apuntar las partidas online a tu servidor en **Configuración → Servidor online**.

---

## 4. Desarrollo y compilación

```bash
npm run setup            # servidor + cliente (copia Stockfish a client/public/stockfish)
npm run dev:server       # terminal 1: API y sockets en :3000
npm run dev:client       # terminal 2: Vite en :5173 (proxy a :3000)
npm run build            # comprueba tipos y genera client/dist
npm start
```

### Estructura

```
chess-arena-online/
├── package.json              scripts de conveniencia
├── server/
│   └── src/
│       ├── index.js          Express: API REST, archivos estáticos, Socket.IO
│       ├── rooms.js          salas, validación con chess.js, relojes, reconexión, chat, revancha
│       ├── db.js             usuarios (scrypt), sesiones, partidas, rating Elo, cuenta Diego
│       └── lan.js            descubrimiento UDP broadcast + mDNS
└── client/
    ├── scripts/copy-stockfish.mjs
    ├── public/               manifest, service worker, icono, stockfish/
    ├── dist/                 app compilada (incluida en el ZIP)
    └── src/
        ├── App.tsx           navegación, sesión, contexto
        ├── components/       Board, Pieces (SVG), AssistantPanel, ui (relojes, barras, QR…)
        ├── screens/          Login, Menu, ComputerSetup, LocalGame, Lobby, JoinGame,
        │                     OnlineGame, History, Replay, Settings, Profile
        └── lib/              engine (Stockfish UCI), socket, api, storage, sound, chessUtil
```

### API

| Método | Ruta | Descripción |
|---|---|---|
| POST | `/api/register` | Crear cuenta `{username, password}` |
| POST | `/api/login` | Iniciar sesión → `{token, user}` |
| POST | `/api/logout` | Cerrar sesión |
| GET | `/api/me` | Usuario actual (Bearer token) |
| GET | `/api/games` | Historial del servidor del usuario |
| GET | `/api/rooms?mode=online\|lan` | Salas públicas en espera |
| GET | `/api/lan/info` | IPs del anfitrión, estado UDP/mDNS, anfitriones descubiertos |

Eventos Socket.IO: `room:create`, `room:join`, `room:leave`, `game:move`, `game:resign`, `game:draw` (`offer|accept|decline`), `game:rematch`, `chat:send`, `lobby:subscribe` → el servidor emite `room:state` y `lobby:rooms`.

---

## 5. Funciones por pantalla

- **Inicio:** logo, usuario, contraseña, iniciar sesión, jugar como invitado, crear cuenta.
- **Menú:** Jugar online · Jugar por Wi‑Fi local · Contra la computadora · Crear partida privada · Unirse a una partida · Historial · Configuración · Mi perfil.
- **Contra la computadora:** 10 niveles (Elo aproximado 400 → 2800+), color, control de tiempo; también *2 jugadores en este dispositivo*. Deshacer, girar tablero, reiniciar, abandonar.
- **Tablero:** tocar o arrastrar, puntos de jugadas legales, última jugada y jaque resaltados, ventana de promoción, animaciones, coordenadas, material capturado, sonidos sintetizados (sin archivos).
- **Historial:** partidas locales y del servidor, filtros, repetición jugada a jugada y copia del PGN.
- **Configuración:** 4 temas de tablero, movimientos posibles, coordenadas, animaciones, coronar siempre dama, sonido, servidor online, borrar historial.
- **Perfil:** rating, estadísticas online/LAN y contra la computadora, nombre del invitado.

## 6. Notas

- Las contraseñas se guardan con hash **scrypt** y sal; la base de datos está en `server/data/db.json`. Las credenciales de Diego son sólo de demostración.
- Stockfish es software libre con licencia **GPLv3** (ver `client/dist/stockfish/COPYING-GPLv3.txt`).
- Las piezas SVG están dibujadas para este proyecto.
