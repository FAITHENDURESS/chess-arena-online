import { useState } from 'react';
import { useApp } from '../App';
import { Header, Segmented, TIME_CONTROLS } from '../components/ui';
import { PieceSvg } from '../components/Pieces';
import { LEVELS } from '../lib/engine';

export interface LocalConfig {
  mode: 'computer' | 'local';
  color: 'w' | 'b';
  level: number;
  tc: { minutes: number; increment: number } | null;
  seed: number;
}

export default function ComputerSetup() {
  const { go, back } = useApp();
  const [mode, setMode] = useState<'computer' | 'local'>('computer');
  const [color, setColor] = useState<'w' | 'b' | 'random'>('w');
  const [level, setLevel] = useState(4);
  const [tc, setTc] = useState('none');

  function start() {
    const t = TIME_CONTROLS.find((x) => x.value === tc)!;
    go({
      name: 'local-game',
      config: {
        mode,
        color: color === 'random' ? (Math.random() < 0.5 ? 'w' : 'b') : color,
        level,
        tc: t.minutes ? { minutes: t.minutes, increment: t.increment } : null,
        seed: Date.now(),
      },
    });
  }

  return (
    <div className="page">
      <Header title={mode === 'computer' ? 'Contra la computadora' : 'Dos jugadores'} onBack={back} />
      <main className="panel-stack narrow">
        <section className="card">
          <h3>Modo</h3>
          <Segmented
            value={mode}
            onChange={setMode}
            options={[
              { value: 'computer', label: 'Contra Stockfish' },
              { value: 'local', label: '2 jugadores (este dispositivo)' },
            ]}
          />
        </section>

        {mode === 'computer' && (
          <>
            <section className="card">
              <h3>Juegas con</h3>
              <div className="color-pick">
                {(['w', 'random', 'b'] as const).map((c) => (
                  <button key={c} className={`color-btn ${color === c ? 'on' : ''}`} onClick={() => setColor(c)}>
                    {c === 'random' ? (
                      <span className="half-king">
                        <PieceSvg type="k" color="w" />
                        <PieceSvg type="k" color="b" />
                      </span>
                    ) : (
                      <PieceSvg type="k" color={c} />
                    )}
                    <span>{c === 'w' ? 'Blancas' : c === 'b' ? 'Negras' : 'Aleatorio'}</span>
                  </button>
                ))}
              </div>
            </section>
            <section className="card">
              <h3>
                Nivel {level + 1} <span className="muted small">· Elo {LEVELS[level].elo}</span>
              </h3>
              <input className="range" type="range" min={0} max={9} value={level} onChange={(e) => setLevel(Number(e.target.value))} />
              <div className="range-labels muted small">
                <span>Principiante</span>
                <span>Maestro</span>
              </div>
            </section>
          </>
        )}

        <section className="card">
          <h3>Control de tiempo</h3>
          <div className="chip-grid">
            {TIME_CONTROLS.map((t) => (
              <button key={t.value} className={`chip ${tc === t.value ? 'on' : ''}`} onClick={() => setTc(t.value)}>
                {t.label}
              </button>
            ))}
          </div>
        </section>

        <button className="btn primary big full" onClick={start}>
          Comenzar partida
        </button>
      </main>
    </div>
  );
}
