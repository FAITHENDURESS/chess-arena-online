import { useState } from 'react';
import { api, type User } from '../lib/api';
import { getLastUser, setLastUser, setToken } from '../lib/storage';
import { Icon, Logo } from '../components/ui';

export default function Login({ onLoggedIn, onGuest }: { onLoggedIn: (u: User) => void; onGuest: () => void }) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [username, setUsername] = useState(getLastUser());
  const [password, setPassword] = useState('');
  const [password2, setPassword2] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [showPw, setShowPw] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (mode === 'register' && password !== password2) return setError('Las contraseñas no coinciden.');
    setBusy(true);
    try {
      const res = mode === 'login' ? await api.login(username.trim(), password) : await api.register(username.trim(), password);
      setToken(res.token);
      setLastUser(res.user.username);
      onLoggedIn(res.user);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="login-screen">
      <div className="login-bg" aria-hidden="true" />
      <div className="login-card">
        <div className="login-logo">
          <Logo size={76} />
          <div className="brand">
            Chess Arena <span>Online</span>
          </div>
          <div className="muted small">Ajedrez online, por Wi‑Fi local y contra la computadora</div>
        </div>

        <div className="tabs">
          <button className={mode === 'login' ? 'on' : ''} onClick={() => { setMode('login'); setError(null); }}>
            Iniciar sesión
          </button>
          <button className={mode === 'register' ? 'on' : ''} onClick={() => { setMode('register'); setError(null); }}>
            Crear cuenta
          </button>
        </div>

        <form onSubmit={submit} className="form">
          <label className="field">
            <span>Usuario</span>
            <input value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" autoCapitalize="none" spellCheck={false} placeholder="Tu nombre de usuario" required />
          </label>
          <label className="field">
            <span>Contraseña</span>
            <div className="pw-wrap">
              <input
                type={showPw ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                placeholder="••••"
                required
              />
              <button type="button" className="pw-eye" onClick={() => setShowPw(!showPw)} aria-label="Mostrar contraseña">
                <Icon name="eye" size={18} />
              </button>
            </div>
          </label>
          {mode === 'register' && (
            <label className="field">
              <span>Repite la contraseña</span>
              <input type={showPw ? 'text' : 'password'} value={password2} onChange={(e) => setPassword2(e.target.value)} autoComplete="new-password" required />
            </label>
          )}
          {error && <div className="error-box">{error}</div>}
          <button className="btn primary big full" disabled={busy}>
            {busy ? 'Conectando…' : mode === 'login' ? 'Iniciar sesión' : 'Crear cuenta'}
          </button>
        </form>

        <div className="divider">
          <span>o</span>
        </div>
        <button className="btn ghost big full" onClick={onGuest}>
          <Icon name="user" size={18} /> Jugar como invitado
        </button>
        {mode === 'login' && (
          <p className="muted small center">
            ¿No tienes cuenta?{' '}
            <button className="link" onClick={() => setMode('register')}>
              Crea una gratis
            </button>
          </p>
        )}
      </div>
    </div>
  );
}
