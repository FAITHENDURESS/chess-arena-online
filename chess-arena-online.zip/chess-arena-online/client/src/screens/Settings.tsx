import { useState } from 'react';
import { useApp } from '../App';
import Board from '../components/Board';
import { Header, Toggle, useToast } from '../components/ui';
import { api } from '../lib/api';
import { resetSockets } from '../lib/socket';
import { clearLocalHistory, type BoardTheme } from '../lib/storage';
import { play } from '../lib/sound';

const THEMES: { value: BoardTheme; label: string; light: string; dark: string }[] = [
  { value: 'green', label: 'Verde', light: '#ebecd0', dark: '#779556' },
  { value: 'brown', label: 'Madera', light: '#f0d9b5', dark: '#b58863' },
  { value: 'blue', label: 'Azul', light: '#dee3e6', dark: '#8ca2ad' },
  { value: 'gray', label: 'Gris', light: '#d9d9d9', dark: '#8b8b8b' },
];

export default function SettingsScreen() {
  const { settings, updateSettings, back } = useApp();
  const [server, setServer] = useState(settings.serverUrl);
  const [testing, setTesting] = useState(false);
  const toast = useToast();

  async function saveServer() {
    const v = server.trim().replace(/\/+$/, '');
    if (v && !/^https?:\/\//.test(v)) return toast.show('La dirección debe empezar por http:// o https://');
    setTesting(true);
    try {
      if (v) await api.ping(v);
      updateSettings({ serverUrl: v });
      resetSockets();
      toast.show(v ? 'Servidor online guardado' : 'Usando el servidor de la app');
    } catch {
      toast.show('No se pudo conectar con ese servidor');
    } finally {
      setTesting(false);
    }
  }

  return (
    <div className="page">
      <Header title="Configuración" onBack={back} />
      <main className="panel-stack narrow">
        <section className="card">
          <h3>Tablero</h3>
          <div className="theme-grid">
            {THEMES.map((t) => (
              <button key={t.value} className={`theme-btn ${settings.theme === t.value ? 'on' : ''}`} onClick={() => updateSettings({ theme: t.value })}>
                <span className="theme-sw">
                  <i style={{ background: t.light }} />
                  <i style={{ background: t.dark }} />
                  <i style={{ background: t.dark }} />
                  <i style={{ background: t.light }} />
                </span>
                {t.label}
              </button>
            ))}
          </div>
          <div className="preview-board">
            <Board fen="r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3" orientation="w" movable="none" onMove={() => {}} lastMove={{ from: 'b8', to: 'c6' }} settings={settings} />
          </div>
          <Toggle checked={settings.showLegal} onChange={(v) => updateSettings({ showLegal: v })} label="Mostrar movimientos posibles" />
          <Toggle checked={settings.coords} onChange={(v) => updateSettings({ coords: v })} label="Coordenadas" />
          <Toggle checked={settings.animations} onChange={(v) => updateSettings({ animations: v })} label="Animaciones" />
          <Toggle checked={settings.autoQueen} onChange={(v) => updateSettings({ autoQueen: v })} label="Coronar siempre dama" hint="Sin preguntar al promocionar un peón" />
        </section>

        <section className="card">
          <h3>Sonido</h3>
          <Toggle
            checked={settings.sound}
            onChange={(v) => {
              updateSettings({ sound: v });
              if (v) setTimeout(() => play('move'), 50);
            }}
            label="Sonidos al mover piezas"
          />
        </section>

        <section className="card">
          <h3>Servidor online</h3>
          <p className="muted small">
            Déjalo vacío para usar el mismo servidor que sirve la app. Si despliegas el servidor en Internet (Render, Railway, un VPS…), escribe aquí su dirección.
          </p>
          <div className="inline-form">
            <input value={server} onChange={(e) => setServer(e.target.value)} placeholder="https://mi-servidor.com" inputMode="url" autoCapitalize="none" />
            <button className="btn" onClick={saveServer} disabled={testing}>
              {testing ? '…' : 'Guardar'}
            </button>
          </div>
        </section>

        <section className="card">
          <h3>Datos</h3>
          <button
            className="btn ghost danger-text full"
            onClick={() => {
              if (confirm('¿Borrar el historial guardado en este dispositivo?')) {
                clearLocalHistory();
                toast.show('Historial local borrado');
              }
            }}
          >
            Borrar historial local
          </button>
          <p className="muted small center">Chess Arena Online 1.0 · Motor Stockfish 17.1 (GPLv3)</p>
        </section>
      </main>
      {toast.node}
    </div>
  );
}
