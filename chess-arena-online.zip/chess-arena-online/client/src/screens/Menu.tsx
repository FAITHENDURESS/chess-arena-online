import { isRegistered, useApp } from '../App';
import { Avatar, Icon, Logo } from '../components/ui';

export default function Menu() {
  const { user, go, logout, hasAssistant } = useApp();
  const reg = isRegistered(user);

  const items = [
    { icon: 'globe', title: 'Jugar online', desc: 'Partidas por Internet en tiempo real', onClick: () => go({ name: 'lobby', mode: 'online' }) },
    { icon: 'wifi', title: 'Jugar por Wi‑Fi local', desc: 'Sin Internet: misma red o punto de acceso', onClick: () => go({ name: 'lobby', mode: 'lan' }) },
    { icon: 'cpu', title: 'Jugar contra la computadora', desc: 'Stockfish, 10 niveles · o 2 jugadores aquí', onClick: () => go({ name: 'computer-setup' }) },
    { icon: 'lock', title: 'Crear partida privada', desc: 'Invita a un amigo con enlace, código o QR', onClick: () => go({ name: 'lobby', mode: 'online', privateRoom: true }) },
    { icon: 'enter', title: 'Unirse a una partida', desc: 'Introduce el código de sala', onClick: () => go({ name: 'join' }) },
    { icon: 'history', title: 'Historial', desc: 'Repasa tus partidas', onClick: () => go({ name: 'history' }) },
    { icon: 'gear', title: 'Configuración', desc: 'Tablero, sonido y servidor', onClick: () => go({ name: 'settings' }) },
    { icon: 'user', title: 'Mi perfil', desc: reg ? 'Estadísticas y rating' : 'Crea una cuenta para guardar tu progreso', onClick: () => go({ name: 'profile' }) },
  ];

  return (
    <div className="page">
      <header className="menu-head">
        <div className="menu-brand">
          <Logo size={40} />
          <div className="brand sm">
            Chess Arena <span>Online</span>
          </div>
        </div>
        <button className="menu-user" onClick={() => go({ name: 'profile' })}>
          <Avatar name={user?.username || '?'} />
          <div className="mu-text">
            <div className="mu-name">{user?.username}</div>
            <div className="muted small">{reg ? `Rating ${user.rating}` : 'Invitado'}</div>
          </div>
        </button>
      </header>

      {hasAssistant && (
        <div className="assist-note">
          <Icon name="bolt" size={16} /> Chess Assistant activo en esta sesión (panel privado en tus partidas)
        </div>
      )}

      <main className="menu-grid">
        {items.map((it, i) => (
          <button key={it.title} className="menu-card" onClick={it.onClick} style={{ animationDelay: `${i * 35}ms` }}>
            <span className="mc-icon">
              <Icon name={it.icon} size={26} />
            </span>
            <span className="mc-text">
              <span className="mc-title">{it.title}</span>
              <span className="mc-desc">{it.desc}</span>
            </span>
          </button>
        ))}
      </main>

      <footer className="menu-foot">
        <button className="btn ghost sm" onClick={logout}>
          <Icon name="logout" size={16} /> {reg ? 'Cerrar sesión' : 'Salir del modo invitado'}
        </button>
      </footer>
    </div>
  );
}
