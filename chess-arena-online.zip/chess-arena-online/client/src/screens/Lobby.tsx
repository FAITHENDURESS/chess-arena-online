// Sala de espera para partidas online y por Wi‑Fi local (LAN).
import { useEffect, useMemo, useState } from 'react';
import { useApp } from '../App';
import { api, baseFor, type LanInfo, type LobbyRoom, type NetMode } from '../lib/api';
import { emitAck, getSocket } from '../lib/socket';
import { Header, Icon, QR, Segmented, TIME_CONTROLS, tcLabel, useToast, copyText } from '../components/ui';
import { PieceSvg } from '../components/Pieces';

function isLocalHost(h: string) {
  return h === 'localhost' || h === '127.0.0.1' || /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.)/.test(h) || h.endsWith('.local');
}

export default function Lobby({ mode, privateRoom }: { mode: NetMode; privateRoom?: boolean }) {
  const { go, back } = useApp();
  const base = baseFor(mode);
  const socket = useMemo(() => getSocket(base), [base]);
  const [connected, setConnected] = useState(socket.connected);
  const [rooms, setRooms] = useState<LobbyRoom[]>([]);
  const [search, setSearch] = useState('');
  const [tc, setTc] = useState('10+0');
  const [color, setColor] = useState<'w' | 'b' | 'random'>('random');
  const [visibility, setVisibility] = useState<'public' | 'private'>(privateRoom ? 'private' : 'public');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [code, setCode] = useState('');
  const [lan, setLan] = useState<LanInfo | null>(null);
  const [ip, setIp] = useState('');
  const toast = useToast();

  useEffect(() => {
    const onConnect = () => {
      setConnected(true);
      socket.emit('lobby:subscribe', { mode });
    };
    const onDisconnect = () => setConnected(false);
    const onRooms = (p: { mode: NetMode; rooms: LobbyRoom[] }) => p.mode === mode && setRooms(p.rooms);
    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);
    socket.on('lobby:rooms', onRooms);
    if (socket.connected) onConnect();
    return () => {
      socket.emit('lobby:unsubscribe');
      socket.off('connect', onConnect);
      socket.off('disconnect', onDisconnect);
      socket.off('lobby:rooms', onRooms);
    };
  }, [socket, mode]);

  useEffect(() => {
    if (mode !== 'lan') return;
    let alive = true;
    const load = () => api.lanInfo().then((i) => alive && setLan(i)).catch(() => {});
    load();
    const id = window.setInterval(load, 4000);
    return () => {
      alive = false;
      window.clearInterval(id);
    };
  }, [mode]);

  async function create() {
    setBusy(true);
    setError(null);
    try {
      const t = TIME_CONTROLS.find((x) => x.value === tc)!;
      const res = await emitAck<{ ok: boolean; roomId: string; error?: string }>(socket, 'room:create', {
        mode,
        visibility,
        color: color === 'random' ? null : color,
        timeControl: t.minutes ? { minutes: t.minutes, increment: t.increment } : null,
      });
      if (!res.ok) throw new Error(res.error || 'No se pudo crear la sala.');
      go({ name: 'online-game', roomId: res.roomId, mode, base });
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function join(payload: { roomId?: string; code?: string }) {
    setBusy(true);
    setError(null);
    try {
      const res = await emitAck<{ ok: boolean; roomId: string; mode: NetMode; error?: string }>(socket, 'room:join', payload);
      if (!res.ok) throw new Error(res.error || 'No se pudo unir.');
      go({ name: 'online-game', roomId: res.roomId, mode: res.mode, base });
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  function connectIp() {
    let v = ip.trim();
    if (!v) return;
    if (!/^https?:\/\//.test(v)) v = `http://${v}`;
    if (!/:\d+/.test(v.replace(/^https?:\/\//, ''))) v += ':3000';
    location.href = v;
  }

  const q = search.trim().toLowerCase();
  const filtered = rooms.filter((r) => !q || r.host.toLowerCase().includes(q) || r.code.toLowerCase().includes(q) || tcLabel(r.timeControl).toLowerCase().includes(q));
  const lanUrl = lan?.urls[0] || location.origin;
  const servedLocally = isLocalHost(location.hostname);

  return (
    <div className="page">
      <Header
        title={mode === 'lan' ? 'Wi‑Fi local' : privateRoom ? 'Partida privada' : 'Jugar online'}
        onBack={back}
        right={<span className={`conn ${connected ? 'on' : 'off'}`}>{connected ? 'Conectado' : 'Conectando…'}</span>}
      />
      <main className="lobby-layout">
        <div className="panel-stack">
          {mode === 'lan' && (
            <section className="card lan-card">
              <h3>
                <Icon name="wifi" size={18} /> Este anfitrión
              </h3>
              {!servedLocally && (
                <div className="warn-box">
                  Estás usando la app desde Internet. Para jugar sin Internet, abre la app desde el servidor que corre en un dispositivo de tu red (ver README).
                </div>
              )}
              <div className="lan-host">
                <QR text={lanUrl} size={132} />
                <div>
                  <div className="muted small">Los demás dispositivos de tu Wi‑Fi o punto de acceso abren:</div>
                  {(lan?.urls.length ? lan.urls : [location.origin]).map((u) => (
                    <button key={u} className="mono-link" onClick={() => copyText(u).then(() => toast.show('Dirección copiada'))}>
                      {u}
                    </button>
                  ))}
                  {lan && (
                    <div className="muted small">
                      Descubrimiento: UDP {lan.discovery.udp ? '✓' : '✗'} · mDNS {lan.discovery.mdns ? '✓' : '✗'}
                    </div>
                  )}
                </div>
              </div>
              {lan && lan.peers.length > 0 && (
                <>
                  <h4>Otros anfitriones encontrados en la red</h4>
                  <ul className="peer-list">
                    {lan.peers.map((p) => (
                      <li key={p.url}>
                        <div>
                          <b>{p.name}</b>
                          <div className="muted small">
                            {p.ip}:{p.port} · {p.rooms} sala(s) · {p.via.toUpperCase()}
                          </div>
                        </div>
                        <a className="btn sm" href={p.url}>
                          Abrir
                        </a>
                      </li>
                    ))}
                  </ul>
                </>
              )}
              <div className="inline-form">
                <input value={ip} onChange={(e) => setIp(e.target.value)} placeholder="Conectar por IP (ej. 192.168.43.1)" inputMode="url" />
                <button className="btn" onClick={connectIp}>
                  Ir
                </button>
              </div>
            </section>
          )}

          <section className="card">
            <h3>
              <Icon name="plus" size={18} /> Crear sala
            </h3>
            <div className="label">Tiempo</div>
            <div className="chip-grid">
              {TIME_CONTROLS.map((t) => (
                <button key={t.value} className={`chip ${tc === t.value ? 'on' : ''}`} onClick={() => setTc(t.value)}>
                  {t.label}
                </button>
              ))}
            </div>
            <div className="label">Tu color</div>
            <div className="color-pick small">
              {(['w', 'random', 'b'] as const).map((c) => (
                <button key={c} className={`color-btn ${color === c ? 'on' : ''}`} onClick={() => setColor(c)}>
                  {c === 'random' ? (
                    <span className="half-king">
                      <PieceSvg type="k" color="w" />
                      <PieceSvg type="k" color="b" />
                    </span>
                  ) : (
                    <PieceSvg type="k" color={c} />
                  )}
                  <span>{c === 'w' ? 'Blancas' : c === 'b' ? 'Negras' : 'Aleatorio'}</span>
                </button>
              ))}
            </div>
            <div className="label">Visibilidad</div>
            <Segmented
              value={visibility}
              onChange={setVisibility}
              options={[
                { value: 'public', label: 'Pública (aparece en la lista)' },
                { value: 'private', label: 'Privada (sólo con código)' },
              ]}
            />
            {error && <div className="error-box">{error}</div>}
            <button className="btn primary big full" onClick={create} disabled={busy || !connected}>
              {busy ? 'Creando…' : 'Crear sala'}
            </button>
          </section>
        </div>

        <div className="panel-stack">
          <section className="card">
            <h3>
              <Icon name="enter" size={18} /> Unirse con código
            </h3>
            <div className="inline-form">
              <input
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6))}
                placeholder="ABC123"
                className="code-input"
                autoCapitalize="characters"
              />
              <button className="btn primary" disabled={code.length < 6 || busy || !connected} onClick={() => join({ code })}>
                Unirse
              </button>
            </div>
          </section>

          <section className="card">
            <h3>
              <Icon name="search" size={18} /> Salas disponibles {mode === 'lan' ? 'en la red' : ''}
            </h3>
            <input className="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar por jugador, código o tiempo" />
            {filtered.length === 0 ? (
              <div className="empty">
                <div className="muted">No hay salas públicas esperando.</div>
                <div className="muted small">Crea una y comparte el código.</div>
              </div>
            ) : (
              <ul className="room-list">
                {filtered.map((r) => (
                  <li key={r.id}>
                    <div className="rl-color">
                      <PieceSvg type="k" color={r.hostColor === 'w' ? 'b' : 'w'} />
                    </div>
                    <div className="rl-info">
                      <b>{r.host}</b> {r.hostRating ? <span className="muted small">({r.hostRating})</span> : <span className="muted small">invitado</span>}
                      <div className="muted small">
                        {tcLabel(r.timeControl)} · Código {r.code} · jugarías con {r.hostColor === 'w' ? 'negras' : 'blancas'}
                      </div>
                    </div>
                    <button className="btn primary sm" onClick={() => join({ roomId: r.id })} disabled={busy}>
                      Jugar
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      </main>
      {toast.node}
    </div>
  );
}
