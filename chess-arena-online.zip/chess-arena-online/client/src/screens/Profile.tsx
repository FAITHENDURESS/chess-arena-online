import { useEffect, useMemo, useState } from 'react';
import { isRegistered, useApp } from '../App';
import { api } from '../lib/api';
import { loadLocalHistory, setGuestName } from '../lib/storage';
import { Avatar, Header, Icon } from '../components/ui';
import { outcomeFor } from './History';

export default function Profile() {
  const { user, setUser, back, logout, hasAssistant } = useApp();
  const reg = isRegistered(user);
  const [guestName, setGuestNameState] = useState(user?.username || '');

  useEffect(() => {
    if (reg) api.me().then(({ user: u }) => setUser(u)).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const local = useMemo(() => {
    const s = { games: 0, wins: 0, losses: 0, draws: 0 };
    for (const r of loadLocalHistory()) {
      if (r.mode === 'online' || r.mode === 'lan') continue;
      const o = outcomeFor(r);
      if (o === 'none') continue;
      s.games++;
      if (o === 'win') s.wins++;
      else if (o === 'loss') s.losses++;
      else s.draws++;
    }
    return s;
  }, []);

  const stats = reg ? user.stats : null;

  return (
    <div className="page">
      <Header title="Mi perfil" onBack={back} />
      <main className="panel-stack narrow">
        <section className="card profile-card">
          <Avatar name={user?.username || '?'} />
          <div>
            <h2>{user?.username}</h2>
            <div className="muted small">
              {reg ? `Miembro desde ${new Date(user.createdAt).toLocaleDateString()}` : 'Jugando como invitado'}
            </div>
            {hasAssistant && (
              <div className="as-badge inline">
                <Icon name="bolt" size={13} /> Chess Assistant
              </div>
            )}
          </div>
          {reg && (
            <div className="rating">
              <div className="muted small">Rating</div>
              <b>{user.rating}</b>
            </div>
          )}
        </section>

        {stats && (
          <section className="card">
            <h3>Partidas online y LAN</h3>
            <div className="stat-grid">
              <div><b>{stats.games}</b><span>Jugadas</span></div>
              <div className="win"><b>{stats.wins}</b><span>Victorias</span></div>
              <div className="loss"><b>{stats.losses}</b><span>Derrotas</span></div>
              <div><b>{stats.draws}</b><span>Tablas</span></div>
            </div>
          </section>
        )}

        <section className="card">
          <h3>Contra la computadora (este dispositivo)</h3>
          <div className="stat-grid">
            <div><b>{local.games}</b><span>Jugadas</span></div>
            <div className="win"><b>{local.wins}</b><span>Victorias</span></div>
            <div className="loss"><b>{local.losses}</b><span>Derrotas</span></div>
            <div><b>{local.draws}</b><span>Tablas</span></div>
          </div>
        </section>

        {!reg && (
          <section className="card">
            <h3>Nombre de invitado</h3>
            <div className="inline-form">
              <input value={guestName} maxLength={24} onChange={(e) => setGuestNameState(e.target.value)} />
              <button
                className="btn"
                onClick={() => {
                  const n = guestName.trim().slice(0, 24) || 'Invitado';
                  setGuestName(n);
                  setUser({ username: n, guest: true });
                }}
              >
                Guardar
              </button>
            </div>
            <p className="muted small">Crea una cuenta para tener rating y guardar tu historial en el servidor.</p>
            <button className="btn primary full" onClick={logout}>
              Crear cuenta / iniciar sesión
            </button>
          </section>
        )}

        {reg && (
          <button className="btn ghost danger-text full" onClick={logout}>
            <Icon name="logout" size={18} /> Cerrar sesión
          </button>
        )}
      </main>
    </div>
  );
}
