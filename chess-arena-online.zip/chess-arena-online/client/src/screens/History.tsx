import { useEffect, useState } from 'react';
import { isRegistered, useApp } from '../App';
import { api, serverGameToRecord } from '../lib/api';
import { loadLocalHistory, type GameRecord } from '../lib/storage';
import { Header, Icon, Segmented } from '../components/ui';

const MODE_LABEL: Record<GameRecord['mode'], string> = {
  computer: 'vs. computadora',
  local: '2 jugadores',
  online: 'Online',
  lan: 'Wi‑Fi local',
};

export function outcomeFor(r: GameRecord): 'win' | 'loss' | 'draw' | 'none' {
  if (r.result === '1/2-1/2') return 'draw';
  if (!r.myColor) return 'none';
  const whiteWon = r.result === '1-0';
  return (r.myColor === 'w') === whiteWon ? 'win' : 'loss';
}

export default function History() {
  const { user, go, back } = useApp();
  const [records, setRecords] = useState<GameRecord[]>(loadLocalHistory);
  const [filter, setFilter] = useState<'all' | GameRecord['mode']>('all');
  const [serverError, setServerError] = useState<string | null>(null);

  useEffect(() => {
    if (!isRegistered(user)) return;
    api
      .games()
      .then(({ games }) => {
        const local = loadLocalHistory();
        const ids = new Set(local.map((r) => r.id));
        const merged = [...local, ...games.map((g) => serverGameToRecord(g, user.id)).filter((r) => !ids.has(r.id))];
        merged.sort((a, b) => b.date - a.date);
        setRecords(merged);
      })
      .catch((e: Error) => setServerError(e.message));
  }, [user]);

  const list = records.filter((r) => filter === 'all' || r.mode === filter);

  return (
    <div className="page">
      <Header title="Historial" onBack={back} />
      <main className="panel-stack narrow">
        <Segmented
          value={filter}
          onChange={setFilter}
          options={[
            { value: 'all', label: 'Todas' },
            { value: 'online', label: 'Online' },
            { value: 'lan', label: 'LAN' },
            { value: 'computer', label: 'CPU' },
            { value: 'local', label: 'Local' },
          ]}
        />
        {serverError && <div className="muted small">Historial del servidor no disponible: {serverError}</div>}
        {list.length === 0 ? (
          <div className="card center muted">
            <Icon name="history" size={32} />
            <p>Todavía no hay partidas terminadas.</p>
          </div>
        ) : (
          <ul className="history-list">
            {list.map((r) => {
              const o = outcomeFor(r);
              return (
                <li key={r.id}>
                  <button className="history-item" onClick={() => go({ name: 'replay', record: r })}>
                    <span className={`res-badge ${o}`}>{o === 'win' ? 'V' : o === 'loss' ? 'D' : o === 'draw' ? '½' : r.result}</span>
                    <span className="hi-main">
                      <span className="hi-players">
                        {r.white} <span className="muted">vs</span> {r.black}
                      </span>
                      <span className="muted small">
                        {MODE_LABEL[r.mode]} · {r.reason} · {Math.ceil(r.moves / 2)} jugadas
                      </span>
                    </span>
                    <span className="muted small hi-date">{new Date(r.date).toLocaleDateString()}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </main>
    </div>
  );
}
