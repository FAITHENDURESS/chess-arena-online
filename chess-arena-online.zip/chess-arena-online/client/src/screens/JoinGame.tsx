import { useEffect, useRef, useState } from 'react';
import { useApp } from '../App';
import { baseFor, type NetMode } from '../lib/api';
import { emitAck, getSocket } from '../lib/socket';
import { Header, Icon } from '../components/ui';

export default function JoinGame({ initialCode }: { initialCode?: string }) {
  const { go, back } = useApp();
  const [code, setCode] = useState(initialCode || '');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const auto = useRef(false);

  async function join(c = code) {
    setBusy(true);
    setError(null);
    // Se prueba primero el servidor que sirve la app (online y LAN) y luego el servidor online configurado.
    const bases = Array.from(new Set(['', baseFor('online')]));
    let lastErr = 'Sala no encontrada.';
    for (const base of bases) {
      try {
        const s = getSocket(base);
        const res = await emitAck<{ ok: boolean; roomId: string; mode: NetMode; error?: string }>(s, 'room:join', { code: c });
        if (res.ok) {
          go({ name: 'online-game', roomId: res.roomId, mode: res.mode, base });
          return;
        }
        lastErr = res.error || lastErr;
      } catch (e) {
        lastErr = (e as Error).message;
      }
    }
    setError(lastErr);
    setBusy(false);
  }

  useEffect(() => {
    if (initialCode && !auto.current) {
      auto.current = true;
      void join(initialCode);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialCode]);

  return (
    <div className="page">
      <Header title="Unirse a una partida" onBack={back} />
      <main className="panel-stack narrow">
        <section className="card center">
          <div className="big-icon">
            <Icon name="enter" size={36} />
          </div>
          <p className="muted">Escribe el código de 6 caracteres que te compartió tu amigo, o escanea su código QR con la cámara.</p>
          <input
            className="code-input big"
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6))}
            placeholder="ABC123"
            autoFocus={!initialCode}
            autoCapitalize="characters"
            onKeyDown={(e) => e.key === 'Enter' && code.length === 6 && join()}
          />
          {error && <div className="error-box">{error}</div>}
          <button className="btn primary big full" disabled={code.length !== 6 || busy} onClick={() => join()}>
            {busy ? 'Buscando sala…' : 'Unirse'}
          </button>
        </section>
      </main>
    </div>
  );
}
