// Partida en tiempo real (online o LAN) sincronizada con el servidor mediante Socket.IO.
import { useEffect, useMemo, useRef, useState } from 'react';
import { Chess, type Color } from 'chess.js';
import { useApp } from '../App';
import Board, { type Arrow, type BoardMove } from '../components/Board';
import AssistantPanel from '../components/AssistantPanel';
import { Header, Icon, Modal, MoveList, PlayerBar, QR, copyText, tcLabel, useToast } from '../components/ui';
import { api, type NetMode } from '../lib/api';
import { emitAck, getSocket } from '../lib/socket';
import { colorName, resultLabel } from '../lib/chessUtil';
import { addLocalHistory } from '../lib/storage';
import { play, playForSan } from '../lib/sound';
import { useNow, useWakeLock } from '../lib/hooks';

interface PlayerInfo {
  name: string;
  guest: boolean;
  rating: number | null;
  connected: boolean;
}

interface ChatMsg {
  name?: string;
  color?: Color | null;
  text: string;
  ts: number;
  system?: boolean;
}

export interface RoomState {
  id: string;
  code: string;
  mode: NetMode;
  visibility: 'public' | 'private';
  timeControl: { minutes: number; increment: number } | null;
  status: 'waiting' | 'playing' | 'ended';
  gameNumber: number;
  fen: string;
  pgn: string;
  moves: { san: string; from: string; to: string }[];
  lastMove: { from: string; to: string } | null;
  turn: Color;
  inCheck: boolean;
  players: { w: PlayerInfo | null; b: PlayerInfo | null };
  clock: { w: number; b: number; running: Color | null; turnStart: number | null } | null;
  serverNow: number;
  result: string | null;
  reason: string | null;
  chat: ChatMsg[];
  drawOffer: Color | null;
  rematch: { w: boolean; b: boolean };
  spectators: number;
  you: Color | 'spectator';
  disconnectDeadline: number | null;
}

// Evita que el doble montaje de React (modo desarrollo) haga abandonar la sala.
const pendingLeave = new Map<string, number>();

export default function OnlineGame({ roomId, mode, base }: { roomId: string; mode: NetMode; base: string }) {
  const { settings, go, hasAssistant } = useApp();
  const socket = useMemo(() => getSocket(base), [base]);
  const [state, setState] = useState<RoomState | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [connected, setConnected] = useState(socket.connected);
  const [offset, setOffset] = useState(0);
  const [pending, setPending] = useState<{ fen: string; san: string; from: string; to: string } | null>(null);
  const [orientationFlip, setOrientationFlip] = useState(false);
  const [tab, setTab] = useState<'moves' | 'chat'>('moves');
  const [unread, setUnread] = useState(0);
  const [chatText, setChatText] = useState('');
  const [arrows, setArrows] = useState<Arrow[]>([]);
  const [confirmResign, setConfirmResign] = useState(false);
  const [showEnd, setShowEnd] = useState(false);
  const [lanUrl, setLanUrl] = useState<string | null>(null);
  const prev = useRef<RoomState | null>(null);
  const soundedLen = useRef(0);
  const chatEnd = useRef<HTMLDivElement>(null);
  const toast = useToast();

  // Conexión y (re)unión a la sala
  useEffect(() => {
    const t = pendingLeave.get(roomId);
    if (t) {
      window.clearTimeout(t);
      pendingLeave.delete(roomId);
    }
    const joinRoom = () => {
      emitAck<{ ok: boolean; error?: string }>(socket, 'room:join', { roomId })
        .then((res) => {
          if (!res.ok) setError(res.error || 'La sala ya no existe.');
        })
        .catch(() => {});
    };
    const onConnect = () => {
      setConnected(true);
      joinRoom();
    };
    const onDisconnect = () => setConnected(false);
    const onState = (s: RoomState) => {
      if (s.id !== roomId) return;
      setOffset(s.serverNow - Date.now());
      setPending(null);
      setState(s);
    };
    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);
    socket.on('room:state', onState);
    if (socket.connected) joinRoom();
    return () => {
      socket.off('connect', onConnect);
      socket.off('disconnect', onDisconnect);
      socket.off('room:state', onState);
      pendingLeave.set(
        roomId,
        window.setTimeout(() => {
          pendingLeave.delete(roomId);
          socket.emit('room:leave', { roomId });
        }, 50)
      );
    };
  }, [socket, roomId]);

  useEffect(() => {
    if (mode !== 'lan') return;
    api.lanInfo().then((i) => setLanUrl(i.urls[0] || null)).catch(() => {});
  }, [mode]);

  // Efectos de sonido / avisos ante cambios de estado
  useEffect(() => {
    if (!state) return;
    const p = prev.current;
    if (p && p.gameNumber !== state.gameNumber) soundedLen.current = 0;
    if (state.moves.length > soundedLen.current) {
      if (soundedLen.current > 0 || state.moves.length === 1 || p) playForSan(state.moves[state.moves.length - 1].san);
    }
    soundedLen.current = state.moves.length;
    if (p && p.status !== 'playing' && state.status === 'playing') play('start');
    if (p && p.status === 'playing' && state.status === 'ended') {
      play('end');
      setShowEnd(true);
    }
    if (p && state.chat.length > p.chat.length) {
      const msg = state.chat[state.chat.length - 1];
      if (!msg.system && tab !== 'chat') {
        setUnread((u) => u + 1);
        play('notify');
      }
    }
    if (p && !p.drawOffer && state.drawOffer && state.drawOffer !== state.you) play('notify');
    prev.current = state;
  }, [state, tab]);

  // Guardar en el historial local cuando termina
  useEffect(() => {
    if (!state || state.status !== 'ended' || !state.result) return;
    addLocalHistory({
      id: `${state.id}-${state.gameNumber}`,
      date: Date.now(),
      mode: state.mode,
      white: state.players.w?.name || '?',
      black: state.players.b?.name || '?',
      result: state.result,
      reason: state.reason || '',
      pgn: state.pgn,
      moves: state.moves.length,
      myColor: state.you === 'spectator' ? null : state.you,
    });
  }, [state?.status, state?.gameNumber]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (tab === 'chat') {
      setUnread(0);
      chatEnd.current?.scrollIntoView({ block: 'end' });
    }
  }, [tab, state?.chat.length]);

  const running = state?.clock?.running ?? null;
  const now = useNow(!!running || !!state?.disconnectDeadline, 100);
  useWakeLock(state?.status === 'playing');

  if (error) {
    return (
      <div className="page">
        <Header title="Partida" onBack={() => go({ name: 'menu' })} />
        <main className="panel-stack narrow">
          <div className="card center">
            <p>{error}</p>
            <button className="btn primary" onClick={() => go({ name: 'menu' })}>
              Volver al menú
            </button>
          </div>
        </main>
      </div>
    );
  }

  if (!state) {
    return (
      <div className="page">
        <Header title="Conectando…" onBack={() => go({ name: 'menu' })} />
        <div className="center pad muted">{connected ? 'Entrando en la sala…' : 'Conectando con el servidor…'}</div>
      </div>
    );
  }

  const you = state.you;
  const isPlayer = you === 'w' || you === 'b';
  const baseOrientation: Color = you === 'b' ? 'b' : 'w';
  const orientation: Color = orientationFlip ? (baseOrientation === 'w' ? 'b' : 'w') : baseOrientation;
  const fen = pending?.fen ?? state.fen;
  const moves = pending ? [...state.moves, pending] : state.moves;
  const last = pending ? { from: pending.from, to: pending.to } : state.lastMove;
  const turn = fen.split(' ')[1] as Color;
  const serverNow = now + offset;

  const clockMs = (c: Color): number | null => {
    if (!state.clock) return null;
    const base = state.clock[c];
    if (state.clock.running === c && state.clock.turnStart) return base - (serverNow - state.clock.turnStart);
    return base;
  };

  function onMove(m: BoardMove) {
    if (!state || !isPlayer || state.status !== 'playing') return;
    try {
      const c = new Chess(state.fen);
      const mv = c.move(m);
      setPending({ fen: c.fen(), san: mv.san, from: mv.from, to: mv.to });
      playForSan(mv.san);
      soundedLen.current = state.moves.length + 1;
    } catch {
      return;
    }
    emitAck<{ ok: boolean; error?: string }>(socket, 'game:move', { roomId, ...m })
      .then((res) => {
        if (!res.ok) {
          setPending(null);
          soundedLen.current = state.moves.length;
          toast.show(res.error || 'Movimiento rechazado');
        }
      })
      .catch((e) => {
        setPending(null);
        toast.show((e as Error).message);
      });
  }

  function sendChat(e: React.FormEvent) {
    e.preventDefault();
    const t = chatText.trim();
    if (!t) return;
    socket.emit('chat:send', { roomId, text: t });
    setChatText('');
  }

  const inviteOrigin = mode === 'lan' ? lanUrl || location.origin : base || location.origin;
  const inviteLink = `${inviteOrigin}/?join=${state.code}`;

  async function share() {
    const text = `¡Juega ajedrez conmigo en Chess Arena Online! Código: ${state!.code}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: 'Chess Arena Online', text, url: inviteLink });
        return;
      } catch {
        /* cancelado */
      }
    }
    if (await copyText(inviteLink)) toast.show('Enlace copiado');
  }

  // ---------- Sala en espera ----------
  if (state.status === 'waiting') {
    const myColor = you === 'w' || you === 'b' ? you : null;
    return (
      <div className="page">
        <Header title={mode === 'lan' ? 'Sala Wi‑Fi local' : 'Sala online'} onBack={() => go({ name: 'menu' })} />
        <main className="panel-stack narrow">
          <section className="card center waiting">
            <div className="muted small">Código de sala</div>
            <button className="room-code" onClick={() => copyText(state.code).then(() => toast.show('Código copiado'))}>
              {state.code}
            </button>
            <QR text={inviteLink} size={190} />
            <div className="muted small break">{inviteLink}</div>
            <div className="row gap center wrap">
              <button className="btn primary" onClick={share}>
                <Icon name="share" size={18} /> Invitar
              </button>
              <button className="btn ghost" onClick={() => copyText(inviteLink).then(() => toast.show('Enlace copiado'))}>
                <Icon name="copy" size={18} /> Copiar enlace
              </button>
            </div>
            <div className="waiting-info">
              <span className="pulse" /> Esperando a tu oponente…
            </div>
            <div className="muted small">
              {tcLabel(state.timeControl)} · Juegas con {myColor ? colorName(myColor).toLowerCase() : '—'} · {state.visibility === 'private' ? 'Privada' : 'Pública'}
            </div>
            {mode === 'lan' && <div className="muted small">El otro dispositivo debe estar en la misma red Wi‑Fi o conectado a tu punto de acceso.</div>}
            <button className="btn ghost danger-text" onClick={() => go({ name: 'menu' })}>
              Cancelar sala
            </button>
          </section>
        </main>
        {toast.node}
      </div>
    );
  }

  // ---------- Partida ----------
  const top: Color = orientation === 'w' ? 'b' : 'w';
  const bottom: Color = orientation;
  const opp: Color | null = isPlayer ? (you === 'w' ? 'b' : 'w') : null;
  const oppDisconnected = opp && state.players[opp] && !state.players[opp]!.connected && state.status === 'playing';
  const dcLeft = state.disconnectDeadline ? Math.max(0, Math.ceil((state.disconnectDeadline - serverNow) / 1000)) : null;

  const bar = (c: Color) => {
    const p = state.players[c];
    return (
      <PlayerBar
        name={p?.name || '—'}
        subtitle={p ? (p.rating ? String(p.rating) : 'invitado') : undefined}
        color={c}
        fen={fen}
        clockMs={clockMs(c)}
        clockActive={state.clock?.running === c}
        isTurn={turn === c && state.status === 'playing'}
        connected={p?.connected ?? false}
      />
    );
  };

  const won = isPlayer && state.result && ((state.result === '1-0' && you === 'w') || (state.result === '0-1' && you === 'b'));

  return (
    <div className="page game-page">
      <Header
        title={mode === 'lan' ? 'Wi‑Fi local' : 'Online'}
        onBack={() => go({ name: 'menu' })}
        right={<span className="tc-chip">{tcLabel(state.timeControl)}</span>}
      />
      {!connected && <div className="banner warn">Conexión perdida. Reconectando…</div>}
      {oppDisconnected && (
        <div className="banner warn">
          {state.players[opp!]!.name} se desconectó{dcLeft !== null ? ` · gana por abandono en ${dcLeft}s si no vuelve` : ''}
        </div>
      )}
      {state.drawOffer && state.status === 'playing' && state.drawOffer !== you && isPlayer && (
        <div className="banner info">
          {state.players[state.drawOffer]?.name} ofrece tablas
          <button className="btn sm primary" onClick={() => socket.emit('game:draw', { roomId, action: 'accept' })}>
            Aceptar
          </button>
          <button className="btn sm ghost" onClick={() => socket.emit('game:draw', { roomId, action: 'decline' })}>
            Rechazar
          </button>
        </div>
      )}

      <div className="game-layout">
        <div className="game-main">
          {bar(top)}
          <div className="board-wrap">
            <Board
              fen={fen}
              orientation={orientation}
              movable={isPlayer && state.status === 'playing' && !pending ? (you as Color) : 'none'}
              onMove={onMove}
              lastMove={last}
              arrows={hasAssistant ? arrows : undefined}
              animKey={moves.length + state.gameNumber * 1000}
              settings={settings}
            />
          </div>
          {bar(bottom)}
          <div className="turn-indicator">
            {state.status === 'ended'
              ? resultLabel(state.result, state.reason)
              : `${isPlayer ? (turn === you ? 'Tu turno' : 'Turno del rival') : `Turno: ${colorName(turn)}`}${state.inCheck ? ' · ¡Jaque!' : ''}`}
            {state.spectators > 0 && <span className="muted small"> · {state.spectators} espectador(es)</span>}
          </div>
          <div className="controls">
            {state.status === 'playing' && isPlayer ? (
              <>
                <button className="ctl" onClick={() => socket.emit('game:draw', { roomId, action: 'offer' })} disabled={!!state.drawOffer}>
                  <Icon name="half" />
                  <span>{state.drawOffer === you ? 'Ofrecidas' : 'Tablas'}</span>
                </button>
                <button className="ctl danger" onClick={() => setConfirmResign(true)}>
                  <Icon name="flag" />
                  <span>Abandonar</span>
                </button>
              </>
            ) : state.status === 'ended' && isPlayer ? (
              <button className="ctl" onClick={() => socket.emit('game:rematch', { roomId })} disabled={state.rematch[you as Color]}>
                <Icon name="restart" />
                <span>{state.rematch[you as Color] ? 'Esperando…' : 'Revancha'}</span>
              </button>
            ) : null}
            <button className="ctl" onClick={() => setOrientationFlip(!orientationFlip)}>
              <Icon name="flip" />
              <span>Girar</span>
            </button>
            <button className="ctl" onClick={() => setTab(tab === 'chat' ? 'moves' : 'chat')}>
              <Icon name="chat" />
              <span>Chat{unread ? ` (${unread})` : ''}</span>
            </button>
          </div>
        </div>

        <aside className="game-side">
          <section className="card side-tabs">
            <div className="tabs small">
              <button className={tab === 'moves' ? 'on' : ''} onClick={() => setTab('moves')}>
                Jugadas
              </button>
              <button className={tab === 'chat' ? 'on' : ''} onClick={() => setTab('chat')}>
                Chat {unread > 0 && <span className="badge">{unread}</span>}
              </button>
            </div>
            {tab === 'moves' ? (
              <MoveList moves={moves.map((m) => m.san)} />
            ) : (
              <div className="chat">
                <div className="chat-list">
                  {state.chat.map((m, i) =>
                    m.system ? (
                      <div key={i} className="chat-sys">
                        {m.text}
                      </div>
                    ) : (
                      <div key={i} className={`chat-msg ${m.color === you ? 'mine' : ''}`}>
                        <span className="chat-name">{m.name}</span>
                        <span>{m.text}</span>
                      </div>
                    )
                  )}
                  <div ref={chatEnd} />
                </div>
                <form className="chat-form" onSubmit={sendChat}>
                  <input value={chatText} onChange={(e) => setChatText(e.target.value)} placeholder="Escribe un mensaje…" maxLength={300} />
                  <button className="icon-btn" aria-label="Enviar">
                    <Icon name="send" size={18} />
                  </button>
                </form>
              </div>
            )}
          </section>
          {hasAssistant && (
            <AssistantPanel fen={fen} myColor={isPlayer ? (you as Color) : null} onArrows={setArrows} disabled={state.status !== 'playing' || !!pending} />
          )}
          <section className="card small muted">
            Sala {state.code} · {state.mode === 'lan' ? 'Wi‑Fi local' : 'Online'} · Partida #{state.gameNumber}
          </section>
        </aside>
      </div>

      {confirmResign && (
        <Modal onClose={() => setConfirmResign(false)}>
          <h2>¿Abandonar la partida?</h2>
          <p className="muted">Tu rival ganará la partida.</p>
          <div className="row gap">
            <button className="btn ghost" onClick={() => setConfirmResign(false)}>
              Cancelar
            </button>
            <button
              className="btn danger"
              onClick={() => {
                setConfirmResign(false);
                socket.emit('game:resign', { roomId });
              }}
            >
              Abandonar
            </button>
          </div>
        </Modal>
      )}

      {showEnd && state.status === 'ended' && (
        <Modal onClose={() => setShowEnd(false)}>
          <div className="result-icon">
            <Icon name="trophy" size={40} />
          </div>
          <h2>{state.result === '1/2-1/2' ? 'Tablas' : isPlayer ? (won ? '¡Has ganado!' : 'Has perdido') : resultLabel(state.result)}</h2>
          <p className="muted">
            {state.reason} · {state.result}
          </p>
          <div className="row gap wrap center">
            <button className="btn ghost" onClick={() => setShowEnd(false)}>
              Ver tablero
            </button>
            {isPlayer && (
              <button
                className="btn primary"
                onClick={() => {
                  socket.emit('game:rematch', { roomId });
                  setShowEnd(false);
                }}
              >
                Revancha
              </button>
            )}
            <button className="btn ghost" onClick={() => go({ name: 'menu' })}>
              Menú
            </button>
          </div>
        </Modal>
      )}
      {toast.node}
    </div>
  );
}
