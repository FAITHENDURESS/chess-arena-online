// Partida local: contra Stockfish o entre dos jugadores en el mismo dispositivo.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Chess, type Color } from 'chess.js';
import { useApp } from '../App';
import Board, { type Arrow, type BoardMove } from '../components/Board';
import AssistantPanel from '../components/AssistantPanel';
import { Header, Icon, Modal, MoveList, PlayerBar, tcLabel } from '../components/ui';
import { StockfishEngine, LEVELS } from '../lib/engine';
import { buildPgn, colorName, gameOverInfo, resultLabel, todayPgnDate } from '../lib/chessUtil';
import { addLocalHistory } from '../lib/storage';
import { play, playForSan } from '../lib/sound';
import { useNow, useWakeLock } from '../lib/hooks';
import type { LocalConfig } from './ComputerSetup';

interface ClockState {
  w: number;
  b: number;
  turnStart: number | null;
}

export default function LocalGame({ config }: { config: LocalConfig }) {
  const { user, settings, go, hasAssistant } = useApp();
  const chessRef = useRef(new Chess());
  const [, setVersion] = useState(0);
  const bump = () => setVersion((v) => v + 1);
  const chess = chessRef.current;

  const vsComputer = config.mode === 'computer';
  const myColor: Color = config.color;
  const [orientation, setOrientation] = useState<Color>(vsComputer ? myColor : 'w');
  const [over, setOver] = useState<{ result: string; reason: string } | null>(null);
  const [showOver, setShowOver] = useState(false);
  const [thinking, setThinking] = useState(false);
  const [arrows, setArrows] = useState<Arrow[]>([]);
  const [confirmResign, setConfirmResign] = useState(false);
  const [gameId, setGameId] = useState(() => `local-${Date.now()}`);
  const [clock, setClock] = useState<ClockState | null>(
    config.tc ? { w: config.tc.minutes * 60_000, b: config.tc.minutes * 60_000, turnStart: null } : null
  );
  const engineRef = useRef<StockfishEngine | null>(null);
  const engineToken = useRef(0);
  const savedRef = useRef<string | null>(null);

  const meName = user?.username || 'Tú';
  const names = useMemo(() => {
    if (!vsComputer) return { w: 'Blancas', b: 'Negras' };
    const cpu = `Stockfish · Nivel ${config.level + 1}`;
    return myColor === 'w' ? { w: meName, b: cpu } : { w: cpu, b: meName };
  }, [vsComputer, config.level, myColor, meName]);

  const history = chess.history({ verbose: true });
  const sans = history.map((m) => m.san);
  const last = history[history.length - 1];
  const fen = chess.fen();
  const turn = chess.turn();

  useWakeLock(!over);

  useEffect(() => {
    if (!vsComputer) return;
    const e = new StockfishEngine();
    engineRef.current = e;
    return () => {
      e.terminate();
      engineRef.current = null;
    };
  }, [vsComputer]);

  const finish = useCallback(
    (result: string, reason: string) => {
      setClock((c) => (c && c.turnStart ? { ...c, [chess.turn()]: Math.max(0, c[chess.turn()] - (Date.now() - c.turnStart)), turnStart: null } : c));
      setOver({ result, reason });
      setShowOver(true);
      play('end');
    },
    [chess]
  );

  // Guardar en el historial al terminar
  useEffect(() => {
    if (!over || savedRef.current === gameId) return;
    savedRef.current = gameId;
    const h = chess.history();
    addLocalHistory({
      id: gameId,
      date: Date.now(),
      mode: config.mode,
      white: names.w,
      black: names.b,
      result: over.result,
      reason: over.reason,
      moves: h.length,
      myColor: vsComputer ? myColor : null,
      pgn: buildPgn(h, {
        Event: vsComputer ? 'Chess Arena — contra la computadora' : 'Chess Arena — partida local',
        Date: todayPgnDate(),
        White: names.w,
        Black: names.b,
        Result: over.result,
        Termination: over.reason,
      }),
    });
  }, [over, gameId, chess, config.mode, names, vsComputer, myColor]);

  const applyMove = useCallback(
    (m: BoardMove | { from: string; to: string; promotion?: string }) => {
      if (over) return false;
      let mv;
      try {
        mv = chess.move(m);
      } catch {
        return false;
      }
      const now = Date.now();
      setClock((c) => {
        if (!c || !config.tc) return c;
        const n = { ...c };
        if (c.turnStart) n[mv.color] = c[mv.color] - (now - c.turnStart) + config.tc.increment * 1000;
        n.turnStart = now;
        return n;
      });
      playForSan(mv.san);
      bump();
      const end = gameOverInfo(chess);
      if (end) finish(end.result, end.reason);
      return true;
    },
    [chess, over, config.tc, finish]
  );

  // Turno de la computadora
  useEffect(() => {
    if (!vsComputer || over || turn === myColor) return;
    const e = engineRef.current;
    if (!e) return;
    const token = ++engineToken.current;
    const lv = LEVELS[config.level];
    setThinking(true);
    const startFen = fen;
    const delay = window.setTimeout(() => {
      e.search(startFen, `depth ${lv.depth} movetime ${lv.movetime}`, {
        setup: () => e.setOption('Skill Level', lv.skill),
      })
        .then((res) => {
          if (token !== engineToken.current || chess.fen() !== startFen) return;
          setThinking(false);
          if (res?.bestmove) applyMove({ from: res.bestmove.slice(0, 2), to: res.bestmove.slice(2, 4), promotion: res.bestmove[4] });
        })
        .catch(() => setThinking(false));
    }, 250);
    return () => window.clearTimeout(delay);
  }, [vsComputer, over, turn, myColor, fen, config.level, applyMove, chess]);

  // Relojes
  const now = useNow(!!clock?.turnStart && !over);
  const shownClock = (c: Color) => {
    if (!clock) return null;
    if (clock.turnStart && turn === c && !over) return clock[c] - (now - clock.turnStart);
    return clock[c];
  };
  useEffect(() => {
    if (!clock?.turnStart || over) return;
    const left = clock[turn] - (now - clock.turnStart);
    if (left <= 0) {
      const opp: Color = turn === 'w' ? 'b' : 'w';
      finish(opp === 'w' ? '1-0' : '0-1', `Tiempo agotado (${colorName(turn).toLowerCase()})`);
    }
  }, [now, clock, turn, over, finish]);

  function onBoardMove(m: BoardMove) {
    applyMove(m);
  }

  function undo() {
    engineToken.current++;
    engineRef.current?.stop();
    setThinking(false);
    if (!history.length) return;
    chess.undo();
    // Contra la computadora se deshace también su respuesta para volver a tu turno
    if (vsComputer && chess.turn() !== myColor && chess.history().length) chess.undo();
    if (over) {
      setOver(null);
      setShowOver(false);
      setGameId(`local-${Date.now()}`);
    }
    if (clock) setClock({ ...clock, turnStart: chess.history().length ? Date.now() : null });
    bump();
  }

  function restart() {
    engineToken.current++;
    engineRef.current?.stop();
    chess.reset();
    setThinking(false);
    setOver(null);
    setShowOver(false);
    setArrows([]);
    setGameId(`local-${Date.now()}`);
    setClock(config.tc ? { w: config.tc.minutes * 60_000, b: config.tc.minutes * 60_000, turnStart: null } : null);
    play('start');
    bump();
  }

  function resign() {
    setConfirmResign(false);
    const loser: Color = vsComputer ? myColor : turn;
    finish(loser === 'w' ? '0-1' : '1-0', `${colorName(loser)} abandonan`);
  }

  const movable = over ? 'none' : vsComputer ? (thinking ? 'none' : myColor) : 'both';
  const top: Color = orientation === 'w' ? 'b' : 'w';
  const bottom: Color = orientation;

  const bar = (c: Color) => (
    <PlayerBar
      name={names[c]}
      subtitle={vsComputer && c !== myColor && thinking ? 'pensando…' : undefined}
      color={c}
      fen={fen}
      clockMs={shownClock(c)}
      clockActive={!!clock?.turnStart && turn === c && !over}
      isTurn={turn === c && !over}
    />
  );

  return (
    <div className="page game-page">
      <Header
        title={vsComputer ? 'Contra la computadora' : 'Partida local'}
        onBack={() => go({ name: 'menu' })}
        right={<span className="tc-chip">{tcLabel(config.tc)}</span>}
      />
      <div className="game-layout">
        <div className="game-main">
          {bar(top)}
          <div className="board-wrap">
            <Board
              fen={fen}
              orientation={orientation}
              movable={movable}
              onMove={onBoardMove}
              lastMove={last ? { from: last.from, to: last.to } : null}
              arrows={hasAssistant ? arrows : undefined}
              animKey={history.length}
              settings={settings}
            />
          </div>
          {bar(bottom)}
          <div className="turn-indicator">
            {over ? resultLabel(over.result, over.reason) : `Turno: ${colorName(turn)}${chess.inCheck() ? ' · ¡Jaque!' : ''}`}
          </div>
          <div className="controls">
            <button className="ctl" onClick={undo} disabled={!history.length}>
              <Icon name="undo" />
              <span>Deshacer</span>
            </button>
            <button className="ctl" onClick={() => setOrientation(orientation === 'w' ? 'b' : 'w')}>
              <Icon name="flip" />
              <span>Girar</span>
            </button>
            <button className="ctl" onClick={restart}>
              <Icon name="restart" />
              <span>Reiniciar</span>
            </button>
            <button className="ctl danger" onClick={() => setConfirmResign(true)} disabled={!!over}>
              <Icon name="flag" />
              <span>Abandonar</span>
            </button>
          </div>
        </div>

        <aside className="game-side">
          <section className="card">
            <h3>Jugadas</h3>
            <MoveList moves={sans} />
          </section>
          {hasAssistant && <AssistantPanel fen={fen} myColor={vsComputer ? myColor : null} onArrows={setArrows} disabled={!!over} />}
        </aside>
      </div>

      {confirmResign && (
        <Modal onClose={() => setConfirmResign(false)}>
          <h2>¿Abandonar la partida?</h2>
          <p className="muted">{vsComputer ? 'Se registrará como derrota.' : `Abandonan las ${colorName(turn).toLowerCase()}.`}</p>
          <div className="row gap">
            <button className="btn ghost" onClick={() => setConfirmResign(false)}>Cancelar</button>
            <button className="btn danger" onClick={resign}>Abandonar</button>
          </div>
        </Modal>
      )}

      {over && showOver && (
        <Modal onClose={() => setShowOver(false)}>
          <div className="result-icon"><Icon name="trophy" size={40} /></div>
          <h2>{over.result === '1/2-1/2' ? 'Tablas' : vsComputer ? (over.result === (myColor === 'w' ? '1-0' : '0-1') ? '¡Has ganado!' : 'Has perdido') : over.result === '1-0' ? 'Ganan las blancas' : 'Ganan las negras'}</h2>
          <p className="muted">{over.reason} · {over.result}</p>
          <div className="row gap wrap center">
            <button className="btn ghost" onClick={() => setShowOver(false)}>Ver tablero</button>
            <button className="btn primary" onClick={restart}>Jugar otra</button>
            <button className="btn ghost" onClick={() => go({ name: 'menu' })}>Menú</button>
          </div>
        </Modal>
      )}
    </div>
  );
}
