// Revisión de una partida terminada, jugada a jugada.
import { useEffect, useMemo, useState } from 'react';
import { Chess, type Color } from 'chess.js';
import { useApp } from '../App';
import Board, { type Arrow } from '../components/Board';
import AssistantPanel from '../components/AssistantPanel';
import { Header, Icon, MoveList, PlayerBar, copyText, useToast } from '../components/ui';
import { resultLabel } from '../lib/chessUtil';
import type { GameRecord } from '../lib/storage';

export default function Replay({ record }: { record: GameRecord }) {
  const { settings, back, hasAssistant } = useApp();
  const toast = useToast();
  const [arrows, setArrows] = useState<Arrow[]>([]);
  const [orientation, setOrientation] = useState<Color>(record.myColor === 'b' ? 'b' : 'w');

  const { fens, moves } = useMemo(() => {
    const c = new Chess();
    try {
      c.loadPgn(record.pgn);
    } catch {
      /* PGN inválido */
    }
    const hist = c.history({ verbose: true });
    return { fens: [hist[0]?.before ?? new Chess().fen(), ...hist.map((m) => m.after)], moves: hist };
  }, [record.pgn]);

  const [idx, setIdx] = useState(moves.length); // número de jugadas aplicadas
  const fen = fens[idx];
  const last = idx > 0 ? moves[idx - 1] : null;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') setIdx((i) => Math.max(0, i - 1));
      if (e.key === 'ArrowRight') setIdx((i) => Math.min(moves.length, i + 1));
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [moves.length]);

  const top: Color = orientation === 'w' ? 'b' : 'w';
  const names = { w: record.white, b: record.black };

  return (
    <div className="page game-page">
      <Header title="Repetición" onBack={back} />
      <div className="game-layout">
        <div className="game-main">
          <PlayerBar name={names[top]} color={top} fen={fen} isTurn={false} />
          <div className="board-wrap">
            <Board fen={fen} orientation={orientation} movable="none" onMove={() => {}} lastMove={last} animKey={idx} arrows={hasAssistant ? arrows : undefined} settings={settings} />
          </div>
          <PlayerBar name={names[orientation]} color={orientation} fen={fen} isTurn={false} />
          <div className="turn-indicator">{resultLabel(record.result, record.reason)}</div>
          <div className="controls">
            <button className="ctl" onClick={() => setIdx(0)} disabled={idx === 0}><Icon name="first" /><span>Inicio</span></button>
            <button className="ctl" onClick={() => setIdx(Math.max(0, idx - 1))} disabled={idx === 0}><Icon name="prev" /><span>Atrás</span></button>
            <button className="ctl" onClick={() => setIdx(Math.min(moves.length, idx + 1))} disabled={idx === moves.length}><Icon name="next" /><span>Adelante</span></button>
            <button className="ctl" onClick={() => setIdx(moves.length)} disabled={idx === moves.length}><Icon name="last" /><span>Final</span></button>
            <button className="ctl" onClick={() => setOrientation(orientation === 'w' ? 'b' : 'w')}><Icon name="flip" /><span>Girar</span></button>
          </div>
        </div>
        <aside className="game-side">
          <section className="card">
            <h3>Jugadas</h3>
            <MoveList moves={moves.map((m) => m.san)} current={idx - 1} onSelect={(i) => setIdx(i + 1)} />
          </section>
          {hasAssistant && <AssistantPanel fen={fen} onArrows={setArrows} />}
          <section className="card">
            <h3>PGN</h3>
            <pre className="pgn">{record.pgn}</pre>
            <button className="btn ghost full" onClick={() => copyText(record.pgn).then(() => toast.show('PGN copiado'))}>
              <Icon name="copy" size={18} /> Copiar PGN
            </button>
          </section>
        </aside>
      </div>
      {toast.node}
    </div>
  );
}
