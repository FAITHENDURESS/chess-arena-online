// Componentes de interfaz reutilizables.
import { useEffect, useRef, useState, type ReactNode } from 'react';
import QRCode from 'qrcode';
import type { Color } from 'chess.js';
import { PieceSvg } from './Pieces';
import { formatClock, materialInfo } from '../lib/chessUtil';
import { play } from '../lib/sound';

export function Logo({ size = 64 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" aria-label="Chess Arena Online">
      <defs>
        <linearGradient id="lg-logo" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#9ccc65" />
          <stop offset="1" stopColor="#4e8a2e" />
        </linearGradient>
      </defs>
      <rect x="4" y="4" width="92" height="92" rx="22" fill="url(#lg-logo)" />
      <g transform="translate(12 8) scale(.76)">
        <path
          d="M30 76C30 64 35 56 44 50C38 52 30 56 24 58C18 60 14 56 16 51C20 42 30 32 40 24L44 12L52 20C66 22 76 36 76 52C76 62 74 70 72 76Z"
          fill="#fff"
          stroke="#1f1e1b"
          strokeWidth="3.5"
          strokeLinejoin="round"
        />
        <circle cx="40" cy="34" r="3" fill="#1f1e1b" />
        <rect x="24" y="76" width="54" height="10" rx="4" fill="#fff" stroke="#1f1e1b" strokeWidth="3.5" />
      </g>
    </svg>
  );
}

export function Header({ title, onBack, right }: { title: string; onBack?: () => void; right?: ReactNode }) {
  return (
    <header className="topbar">
      {onBack ? (
        <button className="icon-btn" onClick={onBack} aria-label="Volver">
          <Icon name="back" />
        </button>
      ) : (
        <span style={{ width: 40 }} />
      )}
      <h1>{title}</h1>
      <div className="topbar-right">{right ?? <span style={{ width: 40 }} />}</div>
    </header>
  );
}

const ICONS: Record<string, string> = {
  back: 'M15 5l-7 7 7 7',
  globe: 'M12 3a9 9 0 100 18 9 9 0 000-18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18',
  wifi: 'M2 9a15 15 0 0120 0M5.5 12.5a10 10 0 0113 0M9 16a5 5 0 016 0M12 19.5h.01',
  cpu: 'M7 7h10v10H7zM10 3v4M14 3v4M10 17v4M14 17v4M3 10h4M3 14h4M17 10h4M17 14h4',
  lock: 'M6 11h12v9H6zM8.5 11V8a3.5 3.5 0 017 0v3',
  enter: 'M10 17l5-5-5-5M15 12H3M14 4h5a2 2 0 012 2v12a2 2 0 01-2 2h-5',
  history: 'M3 12a9 9 0 109-9 9 9 0 00-6.4 2.6L3 8M3 3v5h5M12 7v5l3 3',
  gear: 'M12 15a3 3 0 100-6 3 3 0 000 6zM19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 01-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 010-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 014 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 010 4h-.1a1.7 1.7 0 00-1.5 1z',
  user: 'M12 12a4 4 0 100-8 4 4 0 000 8zM4 21a8 8 0 0116 0',
  flag: 'M5 21V4M5 4h11l-2 4 2 4H5',
  half: 'M12 3a9 9 0 100 18zM12 3a9 9 0 010 18',
  undo: 'M9 14L4 9l5-5M4 9h10a6 6 0 010 12h-3',
  restart: 'M3 12a9 9 0 0115.5-6.3L21 8M21 3v5h-5M21 12a9 9 0 01-15.5 6.3L3 16M3 21v-5h5',
  flip: 'M7 4v16M7 20l-3-3M7 20l3-3M17 20V4M17 4l-3 3M17 4l3 3',
  chat: 'M21 12a8 8 0 01-11.6 7.1L4 20l1-4.6A8 8 0 1121 12z',
  share: 'M4 12v7a2 2 0 002 2h12a2 2 0 002-2v-7M16 6l-4-4-4 4M12 2v13',
  copy: 'M9 9h11v11H9zM5 15H4V4h11v1',
  send: 'M22 2L11 13M22 2l-7 20-4-9-9-4z',
  search: 'M11 18a7 7 0 100-14 7 7 0 000 14zM21 21l-5-5',
  plus: 'M12 5v14M5 12h14',
  bolt: 'M13 2L4 14h7l-1 8 9-12h-7z',
  refresh: 'M21 12a9 9 0 11-3-6.7L21 8M21 3v5h-5',
  logout: 'M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9',
  eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 15a3 3 0 100-6 3 3 0 000 6z',
  first: 'M18 6l-6 6 6 6M6 6v12',
  prev: 'M15 6l-6 6 6 6',
  next: 'M9 6l6 6-6 6',
  last: 'M6 6l6 6-6 6M18 6v12',
  trophy: 'M8 21h8M12 17v4M7 4h10v4a5 5 0 01-10 0zM7 6H4a3 3 0 003 4M17 6h3a3 3 0 01-3 4',
};

export function Icon({ name, size = 22 }: { name: keyof typeof ICONS | string; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={ICONS[name] || ''} />
    </svg>
  );
}

export function Modal({ children, onClose }: { children: ReactNode; onClose?: () => void }) {
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        {children}
      </div>
    </div>
  );
}

export function Avatar({ name, color }: { name: string; color?: Color | null }) {
  const letter = (name || '?').replace(/^Invitado-/, 'I')[0]?.toUpperCase();
  return <div className={`avatar ${color === 'b' ? 'avatar-b' : ''}`}>{letter}</div>;
}

/** Reloj de un jugador. `ms` es el tiempo restante ya calculado. */
export function Clock({ ms, active, flagged }: { ms: number; active: boolean; flagged?: boolean }) {
  const low = ms < 20_000;
  const warned = useRef(false);
  useEffect(() => {
    if (active && ms < 10_000 && ms > 0 && !warned.current) {
      warned.current = true;
      play('lowtime');
    }
    if (ms > 12_000) warned.current = false;
  }, [active, ms]);
  return <div className={`clock ${active ? 'active' : ''} ${low ? 'low' : ''} ${flagged ? 'flag' : ''}`}>{formatClock(ms)}</div>;
}

export function PlayerBar({
  name,
  subtitle,
  color,
  fen,
  clockMs,
  clockActive,
  isTurn,
  connected = true,
}: {
  name: string;
  subtitle?: string;
  color: Color;
  fen: string;
  clockMs?: number | null;
  clockActive?: boolean;
  isTurn: boolean;
  connected?: boolean;
}) {
  const mat = materialInfo(fen);
  const caps = mat.capturedBy[color];
  const diff = color === 'w' ? mat.diff : -mat.diff;
  const other: Color = color === 'w' ? 'b' : 'w';
  return (
    <div className={`player-bar ${isTurn ? 'turn' : ''}`}>
      <Avatar name={name} color={color} />
      <div className="pb-info">
        <div className="pb-name">
          <span className={`dot ${connected ? 'on' : 'off'}`} title={connected ? 'Conectado' : 'Desconectado'} />
          {name}
          {subtitle && <span className="pb-sub">{subtitle}</span>}
        </div>
        <div className="captured">
          {caps.map((p, i) => (
            <span key={i} className="cap">
              <PieceSvg type={p} color={other} />
            </span>
          ))}
          {diff > 0 && <span className="diff">+{diff}</span>}
        </div>
      </div>
      {clockMs != null && <Clock ms={clockMs} active={!!clockActive} flagged={clockMs <= 0} />}
    </div>
  );
}

export function MoveList({ moves, current, onSelect }: { moves: string[]; current?: number; onSelect?: (i: number) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (current === undefined || current === moves.length - 1) ref.current?.scrollTo({ top: ref.current.scrollHeight, behavior: 'smooth' });
  }, [moves.length, current]);
  const rows = [];
  for (let i = 0; i < moves.length; i += 2) {
    rows.push(
      <div className="ml-row" key={i}>
        <span className="ml-num">{i / 2 + 1}.</span>
        {[i, i + 1].map((k) =>
          k < moves.length ? (
            <button key={k} className={`ml-move ${(current ?? moves.length - 1) === k ? 'cur' : ''}`} onClick={() => onSelect?.(k)} disabled={!onSelect}>
              {moves[k]}
            </button>
          ) : (
            <span key={k} />
          )
        )}
      </div>
    );
  }
  return (
    <div className="movelist" ref={ref}>
      {moves.length === 0 ? <div className="muted small center pad">Aún no hay jugadas</div> : rows}
    </div>
  );
}

export function QR({ text, size = 180 }: { text: string; size?: number }) {
  const [src, setSrc] = useState('');
  useEffect(() => {
    QRCode.toDataURL(text, { margin: 1, width: size * 2, color: { dark: '#111111', light: '#ffffff' } })
      .then(setSrc)
      .catch(() => setSrc(''));
  }, [text, size]);
  return src ? <img className="qr" src={src} width={size} height={size} alt={`Código QR: ${text}`} /> : <div className="qr" style={{ width: size, height: size }} />;
}

export function Toggle({ checked, onChange, label, hint }: { checked: boolean; onChange: (v: boolean) => void; label: string; hint?: string }) {
  return (
    <label className="toggle-row">
      <div>
        <div>{label}</div>
        {hint && <div className="muted small">{hint}</div>}
      </div>
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <span className="switch" />
    </label>
  );
}

export function Segmented<T extends string | number>({ value, options, onChange }: { value: T; options: { value: T; label: ReactNode }[]; onChange: (v: T) => void }) {
  return (
    <div className="segmented">
      {options.map((o) => (
        <button key={String(o.value)} className={o.value === value ? 'on' : ''} onClick={() => onChange(o.value)} type="button">
          {o.label}
        </button>
      ))}
    </div>
  );
}

export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    // http (LAN) no permite Clipboard API: método alternativo
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  }
}

export function useToast() {
  const [msg, setMsg] = useState<string | null>(null);
  const t = useRef<number>();
  const show = (m: string) => {
    setMsg(m);
    window.clearTimeout(t.current);
    t.current = window.setTimeout(() => setMsg(null), 2200);
  };
  const node = msg ? <div className="toast">{msg}</div> : null;
  return { show, node };
}

export const TIME_CONTROLS: { label: string; value: string; minutes: number; increment: number }[] = [
  { label: 'Sin reloj', value: 'none', minutes: 0, increment: 0 },
  { label: '1 min', value: '1+0', minutes: 1, increment: 0 },
  { label: '3 | 2', value: '3+2', minutes: 3, increment: 2 },
  { label: '5 min', value: '5+0', minutes: 5, increment: 0 },
  { label: '10 min', value: '10+0', minutes: 10, increment: 0 },
  { label: '15 | 10', value: '15+10', minutes: 15, increment: 10 },
  { label: '30 min', value: '30+0', minutes: 30, increment: 0 },
];

export function tcLabel(tc: { minutes: number; increment: number } | null | undefined) {
  if (!tc || !tc.minutes) return 'Sin reloj';
  return tc.increment ? `${tc.minutes} | ${tc.increment}` : `${tc.minutes} min`;
}
