// Juego de piezas SVG propio de Chess Arena Online.
import type { Color, PieceSymbol } from 'chess.js';
import { memo } from 'react';

const STYLE = {
  w: { fill: '#f7f5f0', stroke: '#1d1c1a', detail: '#1d1c1a', shade: '#d9d4c7' },
  b: { fill: '#2c2b29', stroke: '#0c0c0b', detail: '#d8d4cc', shade: '#3e3c39' },
};

function Base({ s }: { s: (typeof STYLE)['w'] }) {
  return <rect x="22" y="77" width="56" height="10" rx="4" fill={s.fill} stroke={s.stroke} strokeWidth="3.5" />;
}

function Shapes({ type, s }: { type: PieceSymbol; s: (typeof STYLE)['w'] }) {
  const common = { fill: s.fill, stroke: s.stroke, strokeWidth: 3.5, strokeLinejoin: 'round' as const };
  switch (type) {
    case 'p':
      return (
        <>
          <path d="M38 48h24l-3 6c6 7 9 14 11 23H30c2-9 5-16 11-23z" {...common} />
          <circle cx="50" cy="33" r="12.5" {...common} />
          <Base s={s} />
        </>
      );
    case 'r':
      return (
        <>
          <path d="M33 42h34l-3 35H36z" {...common} />
          <path d="M27 17h10v7h8v-7h10v7h8v-7h10v20H27z" {...common} />
          <rect x="27" y="36" width="46" height="7" rx="2" {...common} />
          <path d="M37 52h26M36 66h28" stroke={s.shade} strokeWidth="2.5" fill="none" />
          <Base s={s} />
        </>
      );
    case 'n':
      return (
        <>
          <path
            d="M30 77C29 64 34 55 44 49C38 51 31 55 25 57C18 60 13 55 16 50C21 41 30 32 39 24L42 11L51 19C66 21 77 35 77 52C77 62 75 70 73 77Z"
            {...common}
          />
          <path d="M51 19C47 30 60 36 58 52C57 62 54 70 54 77" stroke={s.shade} strokeWidth="2.5" fill="none" />
          <circle cx="39" cy="33" r="3" fill={s.detail} />
          <circle cx="20.5" cy="52" r="1.8" fill={s.detail} />
          <Base s={s} />
        </>
      );
    case 'b':
      return (
        <>
          <path d="M40 58h20c2 7 5 13 9 19H31c4-6 7-12 9-19z" {...common} />
          <ellipse cx="50" cy="57" rx="14" ry="4.5" {...common} />
          <path d="M50 17c-12 8-18 19-15 29 2 6 8 9 15 9s13-3 15-9c3-10-3-21-15-29z" {...common} />
          <circle cx="50" cy="13" r="5" {...common} />
          <path d="M55 29l-9 12" stroke={s.detail} strokeWidth="3.2" strokeLinecap="round" />
          <Base s={s} />
        </>
      );
    case 'q':
      return (
        <>
          <path d="M28 72L19 33L33 54L36 24L44 51L50 20L56 51L64 24L67 54L81 33L72 72Z" {...common} />
          {[
            [19, 31],
            [36, 22],
            [50, 17],
            [64, 22],
            [81, 31],
          ].map(([cx, cy]) => (
            <circle key={cx} cx={cx} cy={cy} r="4.6" {...common} />
          ))}
          <path d="M28 72c8-4 36-4 44 0v5H28z" {...common} />
          <path d="M31 64c10-3 28-3 38 0" stroke={s.shade} strokeWidth="2.5" fill="none" />
          <Base s={s} />
        </>
      );
    case 'k':
      return (
        <>
          <path d="M47 6h6v8h7v6h-7v9h-6v-9h-7v-6h7z" {...common} strokeWidth={3} />
          <path
            d="M50 30c-6 0-9 4-9 8 0 3 2 5 4 7-12-6-25 0-25 11 0 8 7 13 11 21h38c4-8 11-13 11-21 0-11-13-17-25-11 2-2 4-4 4-7 0-4-3-8-9-8z"
            {...common}
          />
          <path d="M50 45v24M32 66c12-4 24-4 36 0" stroke={s.shade} strokeWidth="2.5" fill="none" />
          <Base s={s} />
        </>
      );
  }
}

export const PieceSvg = memo(function PieceSvg({ type, color }: { type: PieceSymbol; color: Color }) {
  return (
    <svg viewBox="0 0 100 100" className="piece-svg" aria-hidden="true">
      <Shapes type={type} s={STYLE[color]} />
    </svg>
  );
});
