// Sonidos sintetizados con WebAudio (sin archivos, funciona sin conexión).
import { loadSettings } from './storage';

let ctx: AudioContext | null = null;

function ac(): AudioContext | null {
  if (!ctx) {
    const C = window.AudioContext || (window as any).webkitAudioContext;
    if (!C) return null;
    ctx = new C();
  }
  if (ctx.state === 'suspended') void ctx.resume();
  return ctx;
}

function knock(freq: number, dur: number, gain: number, noise = 0.6) {
  const a = ac();
  if (!a) return;
  const t = a.currentTime;
  const out = a.createGain();
  out.gain.setValueAtTime(gain, t);
  out.gain.exponentialRampToValueAtTime(0.001, t + dur);
  out.connect(a.destination);

  const osc = a.createOscillator();
  osc.type = 'triangle';
  osc.frequency.setValueAtTime(freq, t);
  osc.frequency.exponentialRampToValueAtTime(freq * 0.5, t + dur);
  osc.connect(out);
  osc.start(t);
  osc.stop(t + dur);

  // Ráfaga corta de ruido = "golpe" de madera
  const len = Math.floor(a.sampleRate * Math.min(dur, 0.05));
  const buf = a.createBuffer(1, len, a.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
  const src = a.createBufferSource();
  src.buffer = buf;
  const f = a.createBiquadFilter();
  f.type = 'bandpass';
  f.frequency.value = freq * 4;
  const g = a.createGain();
  g.gain.value = noise * gain;
  src.connect(f).connect(g).connect(a.destination);
  src.start(t);
}

function tone(freqs: number[], step = 0.12, gain = 0.12) {
  const a = ac();
  if (!a) return;
  freqs.forEach((fr, i) => {
    const t = a.currentTime + i * step;
    const o = a.createOscillator();
    const g = a.createGain();
    o.type = 'sine';
    o.frequency.value = fr;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + step * 1.6);
    o.connect(g).connect(a.destination);
    o.start(t);
    o.stop(t + step * 1.8);
  });
}

export type SoundKind = 'move' | 'capture' | 'check' | 'castle' | 'end' | 'start' | 'notify' | 'lowtime';

export function play(kind: SoundKind) {
  if (!loadSettings().sound) return;
  try {
    switch (kind) {
      case 'move': return knock(420, 0.08, 0.35);
      case 'capture': return knock(260, 0.13, 0.5, 1);
      case 'castle': knock(420, 0.07, 0.3); setTimeout(() => knock(380, 0.07, 0.3), 90); return;
      case 'check': return tone([660, 880], 0.08, 0.1);
      case 'end': return tone([523, 659, 784], 0.14, 0.12);
      case 'start': return tone([392, 523], 0.1, 0.1);
      case 'notify': return tone([880], 0.08, 0.08);
      case 'lowtime': return tone([1000], 0.05, 0.06);
    }
  } catch {
    /* audio no disponible */
  }
}

/** Elige el sonido adecuado a partir de la SAN de una jugada. */
export function playForSan(san: string) {
  if (san.includes('#')) return play('end');
  if (san.includes('+')) return play('check');
  if (san.startsWith('O-O')) return play('castle');
  if (san.includes('x')) return play('capture');
  play('move');
}
