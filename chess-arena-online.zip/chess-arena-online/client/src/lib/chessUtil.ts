import { Chess, type PieceSymbol, type Color, type Square } from 'chess.js';

export const PIECE_NAMES: Record<PieceSymbol, string> = {
  p: 'Peón',
  n: 'Caballo',
  b: 'Alfil',
  r: 'Torre',
  q: 'Dama',
  k: 'Rey',
};

export const colorName = (c: Color) => (c === 'w' ? 'Blancas' : 'Negras');

export function formatClock(ms: number): string {
  const v = Math.max(0, ms);
  const totalSec = Math.floor(v / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  if (v < 20_000) return `${m}:${String(s).padStart(2, '0')}.${Math.floor((v % 1000) / 100)}`;
  return `${m}:${String(s).padStart(2, '0')}`;
}

export function resultLabel(result: string | null, reason?: string | null): string {
  if (!result) return '';
  const who = result === '1-0' ? 'Ganan las blancas' : result === '0-1' ? 'Ganan las negras' : 'Tablas';
  return reason ? `${who} · ${reason}` : who;
}

/** Detecta el final de la partida en una posición local. */
export function gameOverInfo(chess: Chess): { result: string; reason: string } | null {
  if (chess.isCheckmate()) return { result: chess.turn() === 'w' ? '0-1' : '1-0', reason: 'Jaque mate' };
  if (chess.isStalemate()) return { result: '1/2-1/2', reason: 'Rey ahogado' };
  if (chess.isInsufficientMaterial()) return { result: '1/2-1/2', reason: 'Material insuficiente' };
  if (chess.isThreefoldRepetition()) return { result: '1/2-1/2', reason: 'Triple repetición' };
  if (chess.isDrawByFiftyMoves()) return { result: '1/2-1/2', reason: 'Regla de los 50 movimientos' };
  return null;
}

export interface UciInfo {
  san: string;
  from: Square;
  to: Square;
  piece: PieceSymbol;
  color: Color;
  captured?: PieceSymbol;
  promotion?: PieceSymbol;
}

/** Convierte una jugada UCI (e2e4, e7e8q) a SAN e información legible, o null si no es legal. */
export function uciToInfo(fen: string, uci: string): UciInfo | null {
  try {
    const c = new Chess(fen);
    const m = c.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] || undefined });
    return { san: m.san, from: m.from, to: m.to, piece: m.piece, color: m.color, captured: m.captured, promotion: m.promotion };
  } catch {
    return null;
  }
}

/** Convierte una línea de UCIs en SAN (para mostrar variantes). */
export function pvToSan(fen: string, pv: string[], max = 8): string[] {
  const out: string[] = [];
  try {
    const c = new Chess(fen);
    for (const u of pv.slice(0, max)) {
      const m = c.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] || undefined });
      out.push(m.san);
    }
  } catch {
    /* fin de línea */
  }
  return out;
}

const VALUES: Record<PieceSymbol, number> = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };
const START: Record<PieceSymbol, number> = { p: 8, n: 2, b: 2, r: 2, q: 1, k: 1 };

/** Piezas capturadas por cada bando y diferencia de material (para la barra del jugador). */
export function materialInfo(fen: string) {
  const counts: Record<Color, Record<PieceSymbol, number>> = {
    w: { p: 0, n: 0, b: 0, r: 0, q: 0, k: 0 },
    b: { p: 0, n: 0, b: 0, r: 0, q: 0, k: 0 },
  };
  const board = fen.split(' ')[0];
  for (const ch of board) {
    if (/[pnbrqk]/i.test(ch)) {
      const color: Color = ch === ch.toUpperCase() ? 'w' : 'b';
      counts[color][ch.toLowerCase() as PieceSymbol]++;
    }
  }
  const order: PieceSymbol[] = ['q', 'r', 'b', 'n', 'p'];
  // capturedBy[w] = piezas negras que han capturado las blancas
  const capturedBy: Record<Color, PieceSymbol[]> = { w: [], b: [] };
  let score = 0;
  for (const p of order) {
    const missingBlack = Math.max(0, START[p] - counts.b[p]);
    const missingWhite = Math.max(0, START[p] - counts.w[p]);
    for (let i = 0; i < missingBlack; i++) capturedBy.w.push(p);
    for (let i = 0; i < missingWhite; i++) capturedBy.b.push(p);
    score += (counts.w[p] - counts.b[p]) * VALUES[p];
  }
  return { capturedBy, diff: score };
}

export function buildPgn(sans: string[], headers: Record<string, string>): string {
  const c = new Chess();
  for (const s of sans) {
    try {
      c.move(s);
    } catch {
      break;
    }
  }
  for (const [k, v] of Object.entries(headers)) c.setHeader(k, v);
  return c.pgn();
}

export function todayPgnDate() {
  const d = new Date();
  return `${d.getFullYear()}.${String(d.getMonth() + 1).padStart(2, '0')}.${String(d.getDate()).padStart(2, '0')}`;
}
