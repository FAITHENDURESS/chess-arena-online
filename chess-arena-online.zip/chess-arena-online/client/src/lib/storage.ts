// Persistencia local (ajustes, sesión, invitado, historial de partidas locales).

export type BoardTheme = 'green' | 'brown' | 'blue' | 'gray';

export interface Settings {
  sound: boolean;
  showLegal: boolean;
  coords: boolean;
  autoQueen: boolean;
  animations: boolean;
  theme: BoardTheme;
  /** Servidor para partidas online. Vacío = el mismo servidor que sirve la app. */
  serverUrl: string;
}

export const DEFAULT_SETTINGS: Settings = {
  sound: true,
  showLegal: true,
  coords: true,
  autoQueen: false,
  animations: true,
  theme: 'green',
  serverUrl: '',
};

const K = {
  settings: 'ca_settings',
  token: 'ca_token',
  clientId: 'ca_client_id',
  guest: 'ca_guest_name',
  history: 'ca_local_history',
  lastUser: 'ca_last_user',
};

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function write(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* almacenamiento lleno o bloqueado */
  }
}

export function loadSettings(): Settings {
  return { ...DEFAULT_SETTINGS, ...read<Partial<Settings>>(K.settings, {}) };
}
export function saveSettings(s: Settings) {
  write(K.settings, s);
}

export const getToken = (): string | null => read<string | null>(K.token, null);
export const setToken = (t: string | null) => (t ? write(K.token, t) : localStorage.removeItem(K.token));

export const getLastUser = (): string => read<string>(K.lastUser, '');
export const setLastUser = (u: string) => write(K.lastUser, u);

function randomId(): string {
  // crypto.randomUUID sólo existe en contextos seguros (https/localhost); en LAN (http://192.168…) no.
  const c = globalThis.crypto;
  if (c && 'randomUUID' in c && window.isSecureContext) return c.randomUUID();
  const bytes = new Uint8Array(16);
  if (c?.getRandomValues) c.getRandomValues(bytes);
  else for (let i = 0; i < 16; i++) bytes[i] = Math.floor(Math.random() * 256);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
}

/** Identificador estable del dispositivo: permite reconectar al mismo asiento de una sala. */
export function getClientId(): string {
  let id = read<string | null>(K.clientId, null);
  if (!id) {
    id = randomId();
    write(K.clientId, id);
  }
  return id;
}

export function getGuestName(): string {
  let n = read<string | null>(K.guest, null);
  if (!n) {
    n = `Invitado-${Math.floor(1000 + Math.random() * 9000)}`;
    write(K.guest, n);
  }
  return n;
}
export const setGuestName = (n: string) => write(K.guest, n);

export interface GameRecord {
  id: string;
  date: number;
  mode: 'computer' | 'local' | 'online' | 'lan';
  white: string;
  black: string;
  result: string;
  reason: string;
  pgn: string;
  moves: number;
  /** Color con el que jugó el usuario (si aplica). */
  myColor?: 'w' | 'b' | null;
}

export function loadLocalHistory(): GameRecord[] {
  return read<GameRecord[]>(K.history, []);
}
export function addLocalHistory(rec: GameRecord) {
  const list = loadLocalHistory().filter((r) => r.id !== rec.id);
  list.unshift(rec);
  write(K.history, list.slice(0, 150));
}
export function clearLocalHistory() {
  localStorage.removeItem(K.history);
}
