import { io, type Socket } from 'socket.io-client';
import { getClientId, getToken } from './storage';

const sockets = new Map<string, Socket>();
let displayName = '';

export function setDisplayName(name: string) {
  displayName = name;
}

/** Devuelve (o crea) la conexión Socket.IO hacia un servidor. '' = mismo origen. */
export function getSocket(base: string): Socket {
  let s = sockets.get(base);
  if (s) {
    if (s.disconnected) s.connect();
    return s;
  }
  s = io(base || undefined, {
    // Función: en cada reconexión se envían los datos actuales (token, id de dispositivo, nombre).
    auth: (cb) => cb({ token: getToken(), clientId: getClientId(), name: displayName }),
    transports: ['websocket', 'polling'],
    reconnection: true,
    reconnectionDelay: 800,
    reconnectionDelayMax: 4000,
    timeout: 8000,
  });
  sockets.set(base, s);
  return s;
}

/** Cierra todas las conexiones (al iniciar/cerrar sesión, para renovar la identidad). */
export function resetSockets() {
  for (const s of sockets.values()) s.disconnect();
  sockets.clear();
}

export function emitAck<T = any>(socket: Socket, event: string, payload: unknown, timeout = 8000): Promise<T> {
  return new Promise((resolve, reject) => {
    socket.timeout(timeout).emit(event, payload, (err: Error | null, res: T) => {
      if (err) reject(new Error('El servidor no respondió. Revisa la conexión.'));
      else resolve(res);
    });
  });
}
