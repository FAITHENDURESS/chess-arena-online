import { getToken, loadSettings } from './storage';
import type { GameRecord } from './storage';

export interface User {
  id: string;
  username: string;
  createdAt: number;
  rating: number;
  stats: { games: number; wins: number; losses: number; draws: number };
  features: { assistant?: boolean };
  guest: false;
}

export interface GuestUser {
  username: string;
  guest: true;
}

export type AnyUser = User | GuestUser;

export type NetMode = 'online' | 'lan';

/** Base URL del servidor. LAN siempre usa el servidor que sirve la app; online puede configurarse. */
export function baseFor(mode: NetMode): string {
  if (mode === 'lan') return '';
  return loadSettings().serverUrl.trim().replace(/\/+$/, '');
}

async function req<T>(path: string, opts: RequestInit = {}, base = ''): Promise<T> {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  let res: Response;
  try {
    res = await fetch(base + path, { ...opts, headers: { ...headers, ...(opts.headers as object) } });
  } catch {
    throw new Error('No se pudo conectar con el servidor.');
  }
  let data: any = null;
  try {
    data = await res.json();
  } catch {
    /* sin cuerpo */
  }
  if (!res.ok) throw new Error(data?.error || `Error ${res.status}`);
  return data as T;
}

export interface LobbyRoom {
  id: string;
  code: string;
  host: string;
  hostRating: number | null;
  hostColor: 'w' | 'b';
  timeControl: { minutes: number; increment: number } | null;
  createdAt: number;
}

export interface LanInfo {
  name: string;
  port: number;
  ips: string[];
  urls: string[];
  discovery: { udp: boolean; mdns: boolean };
  peers: { name: string; ip: string; port: number; rooms: number; via: string; url: string }[];
  rooms: number;
}

export interface ServerGame {
  id: string;
  date: number;
  mode: 'online' | 'lan';
  white: { name: string; userId: string | null };
  black: { name: string; userId: string | null };
  result: string;
  reason: string;
  pgn: string;
  moves: number;
}

export const api = {
  login: (username: string, password: string) =>
    req<{ token: string; user: User }>('/api/login', { method: 'POST', body: JSON.stringify({ username, password }) }),
  register: (username: string, password: string) =>
    req<{ token: string; user: User }>('/api/register', { method: 'POST', body: JSON.stringify({ username, password }) }),
  logout: () => req<{ ok: true }>('/api/logout', { method: 'POST' }).catch(() => null),
  me: () => req<{ user: User }>('/api/me'),
  games: () => req<{ games: ServerGame[] }>('/api/games'),
  rooms: (mode: NetMode) => req<{ rooms: LobbyRoom[] }>(`/api/rooms?mode=${mode}`, {}, baseFor(mode)),
  lanInfo: () => req<LanInfo>('/api/lan/info'),
  ping: (base = '') => req<{ ok: boolean; name: string }>('/api/ping', {}, base),
};

export function serverGameToRecord(g: ServerGame, myId: string): GameRecord {
  const myColor = g.white.userId === myId ? 'w' : g.black.userId === myId ? 'b' : null;
  return {
    id: g.id,
    date: g.date,
    mode: g.mode,
    white: g.white.name,
    black: g.black.name,
    result: g.result,
    reason: g.reason,
    pgn: g.pgn,
    moves: g.moves,
    myColor,
  };
}
