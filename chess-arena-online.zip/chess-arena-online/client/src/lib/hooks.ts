import { useEffect, useState } from 'react';

/** Devuelve Date.now() actualizado cada `ms` mientras `active` sea true. */
export function useNow(active: boolean, ms = 100): number {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    if (!active) return;
    setNow(Date.now());
    const id = window.setInterval(() => setNow(Date.now()), ms);
    return () => window.clearInterval(id);
  }, [active, ms]);
  return now;
}

/** Mantiene la pantalla encendida durante la partida (si el navegador lo permite). */
export function useWakeLock(active: boolean) {
  useEffect(() => {
    if (!active || !('wakeLock' in navigator)) return;
    let lock: any = null;
    let cancelled = false;
    const req = () =>
      (navigator as any).wakeLock
        .request('screen')
        .then((l: any) => {
          if (cancelled) l.release();
          else lock = l;
        })
        .catch(() => {});
    req();
    const onVis = () => document.visibilityState === 'visible' && req();
    document.addEventListener('visibilitychange', onVis);
    return () => {
      cancelled = true;
      document.removeEventListener('visibilitychange', onVis);
      lock?.release?.().catch?.(() => {});
    };
  }, [active]);
}
