// Envoltorio del motor Stockfish (WASM en un Web Worker) mediante el protocolo UCI.

export interface EngineLine {
  multipv: number;
  depth: number;
  /** Evaluación en centipeones desde el punto de vista de las BLANCAS. */
  cp: number | null;
  /** Mate en N (positivo = ganan blancas, negativo = ganan negras). */
  mate: number | null;
  pv: string[];
}

export interface SearchResult {
  bestmove: string | null;
  lines: EngineLine[];
}

const ENGINE_URL = `${import.meta.env.BASE_URL}stockfish/stockfish.js`;

export class StockfishEngine {
  private worker: Worker | null = null;
  private listeners = new Set<(line: string) => void>();
  private readyP: Promise<void>;
  private queue: Promise<unknown> = Promise.resolve();
  private searching = false;
  private jobSeq = 0;
  failed: string | null = null;

  constructor() {
    this.readyP = new Promise<void>((resolve, reject) => {
      try {
        this.worker = new Worker(ENGINE_URL);
      } catch (e) {
        this.failed = 'No se pudo iniciar Stockfish en este navegador.';
        reject(new Error(this.failed));
        return;
      }
      this.worker.onmessage = (e: MessageEvent) => {
        const text = typeof e.data === 'string' ? e.data : String(e.data);
        for (const line of text.split('\n')) if (line) for (const l of [...this.listeners]) l(line);
      };
      this.worker.onerror = () => {
        this.failed = 'Stockfish no pudo cargarse (¿falta public/stockfish?).';
        reject(new Error(this.failed));
      };
      const onLine = (line: string) => {
        if (line === 'uciok') this.send('isready');
        else if (line === 'readyok') {
          this.listeners.delete(onLine);
          resolve();
        }
      };
      this.listeners.add(onLine);
      this.send('uci');
    });
    this.readyP.catch(() => {});
  }

  ready() {
    return this.readyP;
  }

  send(cmd: string) {
    this.worker?.postMessage(cmd);
  }

  setOption(name: string, value: string | number | boolean) {
    this.send(`setoption name ${name} value ${value}`);
  }

  /** Detiene la búsqueda en curso (si la hay). */
  stop() {
    if (this.searching) this.send('stop');
  }

  /**
   * Lanza una búsqueda. Si se llama de nuevo antes de terminar, la anterior se detiene
   * y sólo la última recibe actualizaciones.
   */
  search(
    fen: string,
    go: string,
    opts: { multipv?: number; onInfo?: (lines: EngineLine[]) => void; setup?: () => void } = {}
  ): Promise<SearchResult | null> {
    const id = ++this.jobSeq;
    this.stop();
    const run = async (): Promise<SearchResult | null> => {
      await this.readyP;
      if (id !== this.jobSeq) return null; // reemplazada antes de empezar
      const blackToMove = fen.split(' ')[1] === 'b';
      const multipv = Math.max(1, Math.min(5, opts.multipv ?? 1));
      opts.setup?.();
      this.setOption('MultiPV', multipv);
      this.send(`position fen ${fen}`);
      const lines = new Map<number, EngineLine>();
      return new Promise<SearchResult>((resolve) => {
        const onLine = (line: string) => {
          if (line.startsWith('info') && line.includes(' pv ')) {
            const parsed = parseInfo(line, blackToMove);
            if (parsed) {
              lines.set(parsed.multipv, parsed);
              if (id === this.jobSeq && opts.onInfo) {
                opts.onInfo([...lines.values()].sort((a, b) => a.multipv - b.multipv));
              }
            }
          } else if (line.startsWith('bestmove')) {
            this.listeners.delete(onLine);
            this.searching = false;
            const bm = line.split(' ')[1];
            resolve({
              bestmove: bm && bm !== '(none)' ? bm : null,
              lines: [...lines.values()].sort((a, b) => a.multipv - b.multipv),
            });
          }
        };
        this.listeners.add(onLine);
        this.searching = true;
        this.send(`go ${go}`);
      });
    };
    const p = this.queue.then(run, run);
    this.queue = p.catch(() => null);
    return p;
  }

  terminate() {
    this.jobSeq++;
    this.listeners.clear();
    this.worker?.terminate();
    this.worker = null;
  }
}

function parseInfo(line: string, blackToMove: boolean): EngineLine | null {
  const t = line.split(' ');
  const get = (k: string) => {
    const i = t.indexOf(k);
    return i >= 0 ? t[i + 1] : undefined;
  };
  const depth = Number(get('depth'));
  const multipv = Number(get('multipv') || 1);
  const si = t.indexOf('score');
  if (si < 0) return null;
  const kind = t[si + 1];
  const val = Number(t[si + 2]);
  const sign = blackToMove ? -1 : 1;
  const pvIdx = t.indexOf('pv');
  const pv = pvIdx >= 0 ? t.slice(pvIdx + 1) : [];
  if (!pv.length) return null;
  return {
    depth,
    multipv,
    cp: kind === 'cp' ? val * sign : null,
    mate: kind === 'mate' ? val * sign : null,
    pv,
  };
}

/** Niveles de la computadora: 1 (principiante) a 10 (máximo). */
export const LEVELS = [
  { skill: 0, depth: 1, movetime: 150, elo: '≈ 400' },
  { skill: 2, depth: 2, movetime: 200, elo: '≈ 700' },
  { skill: 4, depth: 3, movetime: 250, elo: '≈ 900' },
  { skill: 6, depth: 5, movetime: 300, elo: '≈ 1100' },
  { skill: 8, depth: 7, movetime: 400, elo: '≈ 1300' },
  { skill: 10, depth: 9, movetime: 500, elo: '≈ 1500' },
  { skill: 13, depth: 11, movetime: 700, elo: '≈ 1800' },
  { skill: 16, depth: 13, movetime: 900, elo: '≈ 2100' },
  { skill: 18, depth: 16, movetime: 1200, elo: '≈ 2400' },
  { skill: 20, depth: 22, movetime: 1800, elo: '2800+' },
];

export function formatEval(line: Pick<EngineLine, 'cp' | 'mate'> | null | undefined): string {
  if (!line) return '0.0';
  if (line.mate !== null) return line.mate === 0 ? '#' : `${line.mate > 0 ? '+' : '-'}M${Math.abs(line.mate)}`;
  const v = (line.cp ?? 0) / 100;
  return `${v > 0 ? '+' : ''}${v.toFixed(2)}`;
}

/** 0..1 = proporción de la barra para las blancas. */
export function evalToBar(line: Pick<EngineLine, 'cp' | 'mate'> | null | undefined): number {
  if (!line) return 0.5;
  if (line.mate !== null) return line.mate > 0 ? 1 : line.mate < 0 ? 0 : 0.5;
  const cp = line.cp ?? 0;
  return 1 / (1 + Math.exp(-cp / 250));
}
