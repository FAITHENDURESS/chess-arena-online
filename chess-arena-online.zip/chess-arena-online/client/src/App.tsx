import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import type { Color } from 'chess.js';
import { api, type AnyUser, type NetMode, type User } from './lib/api';
import { getGuestName, getToken, loadSettings, saveSettings, setToken, type Settings, type GameRecord } from './lib/storage';
import { resetSockets, setDisplayName } from './lib/socket';
import { Logo } from './components/ui';
import Login from './screens/Login';
import Menu from './screens/Menu';
import ComputerSetup, { type LocalConfig } from './screens/ComputerSetup';
import LocalGame from './screens/LocalGame';
import Lobby from './screens/Lobby';
import JoinGame from './screens/JoinGame';
import OnlineGame from './screens/OnlineGame';
import History from './screens/History';
import Replay from './screens/Replay';
import SettingsScreen from './screens/Settings';
import Profile from './screens/Profile';

export type Screen =
  | { name: 'login' }
  | { name: 'menu' }
  | { name: 'computer-setup' }
  | { name: 'local-game'; config: LocalConfig }
  | { name: 'lobby'; mode: NetMode; privateRoom?: boolean }
  | { name: 'join'; code?: string }
  | { name: 'online-game'; roomId: string; mode: NetMode; base: string }
  | { name: 'history' }
  | { name: 'replay'; record: GameRecord }
  | { name: 'settings' }
  | { name: 'profile' };

interface Ctx {
  user: AnyUser | null;
  setUser: (u: AnyUser | null) => void;
  settings: Settings;
  updateSettings: (patch: Partial<Settings>) => void;
  go: (s: Screen) => void;
  back: () => void;
  logout: () => void;
  hasAssistant: boolean;
}

const AppCtx = createContext<Ctx>(null as unknown as Ctx);
export const useApp = () => useContext(AppCtx);

export function isRegistered(u: AnyUser | null): u is User {
  return !!u && !u.guest;
}

export type { Color };

export default function App() {
  const [user, setUserState] = useState<AnyUser | null>(null);
  const [booting, setBooting] = useState(true);
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [screen, setScreen] = useState<Screen>({ name: 'login' });
  const pendingJoin = useRef<{ code: string } | null>(null);

  const setUser = useCallback((u: AnyUser | null) => {
    setUserState(u);
    setDisplayName(u?.username || '');
    resetSockets();
  }, []);

  // Navegación con historial (botón "atrás" de Android vuelve al menú)
  const go = useCallback((s: Screen) => {
    setScreen(s);
    if (s.name !== 'menu' && s.name !== 'login') window.history.pushState({ app: true }, '');
    window.scrollTo(0, 0);
  }, []);
  const back = useCallback(() => window.history.back(), []);

  useEffect(() => {
    const onPop = () => setScreen((cur) => (cur.name === 'login' ? cur : { name: 'menu' }));
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  // Restaurar sesión
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const join = params.get('join');
    if (join) {
      pendingJoin.current = { code: join.toUpperCase() };
      history.replaceState(null, '', location.pathname);
    }
    const token = getToken();
    const finish = () => setBooting(false);
    if (token) {
      api
        .me()
        .then(({ user }) => {
          setUser(user);
          setScreen({ name: 'menu' });
        })
        .catch((e: Error) => {
          if (!/conectar/.test(e.message)) setToken(null);
        })
        .finally(finish);
    } else finish();
    if ('serviceWorker' in navigator && import.meta.env.PROD && window.isSecureContext) {
      navigator.serviceWorker.register('/sw.js').catch(() => {});
    }
  }, [setUser]);

  // Si se abrió un enlace de invitación, ir directo a la sala tras iniciar sesión
  useEffect(() => {
    if (user && pendingJoin.current) {
      const { code } = pendingJoin.current;
      pendingJoin.current = null;
      go({ name: 'join', code });
    }
  }, [user, go]);

  const updateSettings = useCallback((patch: Partial<Settings>) => {
    setSettings((s) => {
      const n = { ...s, ...patch };
      saveSettings(n);
      return n;
    });
  }, []);

  const logout = useCallback(() => {
    if (getToken()) void api.logout();
    setToken(null);
    setUser(null);
    setScreen({ name: 'login' });
  }, [setUser]);

  const hasAssistant = isRegistered(user) && !!user.features?.assistant;

  if (booting) {
    return (
      <div className="splash">
        <Logo size={84} />
        <div className="brand">Chess Arena <span>Online</span></div>
      </div>
    );
  }

  const ctx: Ctx = { user, setUser, settings, updateSettings, go, back, logout, hasAssistant };

  let content;
  if (!user) {
    content = (
      <Login
        onLoggedIn={(u) => {
          setUser(u);
          setScreen({ name: 'menu' });
        }}
        onGuest={() => {
          setUser({ username: getGuestName(), guest: true });
          setScreen({ name: 'menu' });
        }}
      />
    );
  } else {
    switch (screen.name) {
      case 'login':
      case 'menu':
        content = <Menu />;
        break;
      case 'computer-setup':
        content = <ComputerSetup />;
        break;
      case 'local-game':
        content = <LocalGame key={JSON.stringify(screen.config)} config={screen.config} />;
        break;
      case 'lobby':
        content = <Lobby key={screen.mode + String(screen.privateRoom)} mode={screen.mode} privateRoom={screen.privateRoom} />;
        break;
      case 'join':
        content = <JoinGame initialCode={screen.code} />;
        break;
      case 'online-game':
        content = <OnlineGame key={screen.roomId} roomId={screen.roomId} mode={screen.mode} base={screen.base} />;
        break;
      case 'history':
        content = <History />;
        break;
      case 'replay':
        content = <Replay record={screen.record} />;
        break;
      case 'settings':
        content = <SettingsScreen />;
        break;
      case 'profile':
        content = <Profile />;
        break;
    }
  }

  return <AppCtx.Provider value={ctx}>{content}</AppCtx.Provider>;
}
