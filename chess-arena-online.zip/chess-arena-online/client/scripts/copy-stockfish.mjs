// Copia el motor Stockfish (WASM, versión "lite single-thread") a public/stockfish/
// para que funcione sin Internet y sin cabeceras especiales (no requiere SharedArrayBuffer).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const src = path.join(root, 'node_modules', 'stockfish', 'src');
const dest = path.join(root, 'public', 'stockfish');

if (!fs.existsSync(src)) {
  console.warn('[stockfish] Paquete no encontrado; omitiendo copia.');
  process.exit(0);
}
const files = fs.readdirSync(src);
const js = files.find((f) => /lite-single.*\.js$/.test(f));
const wasm = files.find((f) => /lite-single.*\.wasm$/.test(f));
if (!js || !wasm) {
  console.warn('[stockfish] No se encontró la versión lite-single.');
  process.exit(0);
}
fs.mkdirSync(dest, { recursive: true });
fs.copyFileSync(path.join(src, js), path.join(dest, 'stockfish.js'));
fs.copyFileSync(path.join(src, wasm), path.join(dest, 'stockfish.wasm'));
const lic = path.join(root, 'node_modules', 'stockfish', 'Copying.txt');
if (fs.existsSync(lic)) fs.copyFileSync(lic, path.join(dest, 'COPYING-GPLv3.txt'));
console.log('[stockfish] Motor copiado a public/stockfish/');
