import { useEffect, useId, useMemo, useRef, useState } from 'react';
import { Chess, type Color, type PieceSymbol, type Square } from 'chess.js';
import { PieceSvg } from './Pieces';
import type { Settings } from '../lib/storage';

export interface Arrow {
  from: string;
  to: string;
  color?: string;
  opacity?: number;
  /** 'discreet' = contorno sobre las casillas de origen y destino en lugar de flecha. */
  mode?: 'arrow' | 'discreet';
}

export interface BoardMove {
  from: Square;
  to: Square;
  promotion?: PieceSymbol;
}

interface Props {
  fen: string;
  orientation: Color;
  /** Qué bando puede mover el usuario: 'both' = ambos (partida local en un dispositivo). */
  movable: Color | 'both' | 'none';
  onMove: (m: BoardMove) => void;
  lastMove?: { from: string; to: string } | null;
  arrows?: Arrow[];
  /** Cambia con cada jugada; dispara la animación de la última jugada. */
  animKey?: number;
  settings: Settings;
}

const FILES = 'abcdefgh';

function sqToXY(sq: string, o: Color) {
  const file = FILES.indexOf(sq[0]);
  const rank = Number(sq[1]);
  return { col: o === 'w' ? file : 7 - file, row: o === 'w' ? 8 - rank : rank - 1 };
}
function xyToSq(col: number, row: number, o: Color): Square {
  const file = o === 'w' ? col : 7 - col;
  const rank = o === 'w' ? 8 - row : row + 1;
  return `${FILES[file]}${rank}` as Square;
}

interface DragState {
  from: Square;
  x: number;
  y: number;
  size: number;
  active: boolean;
  startX: number;
  startY: number;
  wasSelected: boolean;
}

export default function Board({ fen, orientation, movable, onMove, lastMove, arrows: marks, animKey = 0, settings }: Props) {
  // Las flechas normales se dibujan exactamente igual que antes; las marcas discretas van en su propia capa.
  const arrows = marks?.filter((m) => m.mode !== 'discreet');
  const discreet = marks?.filter((m) => m.mode === 'discreet') ?? [];
  const uid = useId().replace(/:/g, '');
  const chess = useMemo(() => {
    try {
      return new Chess(fen);
    } catch {
      return new Chess();
    }
  }, [fen]);
  const [selected, setSelected] = useState<Square | null>(null);
  const [drag, setDrag] = useState<DragState | null>(null);
  const [promo, setPromo] = useState<{ from: Square; to: Square; color: Color } | null>(null);
  const boardRef = useRef<HTMLDivElement>(null);
  const skipAnimKey = useRef<number | null>(null);

  useEffect(() => {
    setSelected(null);
    setPromo(null);
  }, [fen, movable]);

  const turn = chess.turn();
  const canMoveColor = (c: Color) => (movable === 'both' ? c === turn : movable === c && turn === c);

  const targets = useMemo(() => {
    const from = drag?.from ?? selected;
    if (!from) return new Map<string, { capture: boolean }>();
    const m = new Map<string, { capture: boolean }>();
    for (const mv of chess.moves({ square: from, verbose: true })) {
      m.set(mv.to, { capture: !!mv.captured });
    }
    return m;
  }, [chess, selected, drag?.from]);

  const checkSquare = useMemo(() => {
    if (!chess.inCheck()) return null;
    for (const row of chess.board()) for (const p of row) if (p && p.type === 'k' && p.color === turn) return p.square;
    return null;
  }, [chess, turn]);

  function squareFromPoint(x: number, y: number): Square | null {
    const el = boardRef.current;
    if (!el) return null;
    const r = el.getBoundingClientRect();
    const col = Math.floor(((x - r.left) / r.width) * 8);
    const row = Math.floor(((y - r.top) / r.height) * 8);
    if (col < 0 || col > 7 || row < 0 || row > 7) return null;
    return xyToSq(col, row, orientation);
  }

  function attempt(from: Square, to: Square): boolean {
    const moves = chess.moves({ square: from, verbose: true }).filter((m) => m.to === to);
    if (!moves.length) return false;
    setSelected(null);
    if (moves.some((m) => m.promotion)) {
      if (settings.autoQueen) onMove({ from, to, promotion: 'q' });
      else setPromo({ from, to, color: moves[0].color });
    } else onMove({ from, to });
    return true;
  }

  function onPointerDown(e: React.PointerEvent) {
    if (promo || movable === 'none') return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    const sq = squareFromPoint(e.clientX, e.clientY);
    if (!sq) return;
    const piece = chess.get(sq);
    if (selected && sq !== selected && targets.has(sq)) {
      attempt(selected, sq);
      return;
    }
    if (piece && canMoveColor(piece.color)) {
      const rect = boardRef.current!.getBoundingClientRect();
      try {
        boardRef.current!.setPointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
      setDrag({
        from: sq,
        x: e.clientX,
        y: e.clientY,
        size: rect.width / 8,
        active: false,
        startX: e.clientX,
        startY: e.clientY,
        wasSelected: selected === sq,
      });
      setSelected(sq);
      e.preventDefault();
    } else {
      setSelected(null);
    }
  }

  function onPointerMove(e: React.PointerEvent) {
    if (!drag) return;
    const moved = drag.active || Math.hypot(e.clientX - drag.startX, e.clientY - drag.startY) > 6;
    setDrag({ ...drag, x: e.clientX, y: e.clientY, active: moved });
  }

  function onPointerUp(e: React.PointerEvent) {
    if (!drag) return;
    const sq = squareFromPoint(e.clientX, e.clientY);
    if (drag.active) {
      if (sq && sq !== drag.from && attempt(drag.from, sq)) skipAnimKey.current = animKey + 1;
    } else if (drag.wasSelected && sq === drag.from) {
      setSelected(null);
    }
    setDrag(null);
  }

  // ---------- render ----------
  const squares = [];
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const sq = xyToSq(col, row, orientation);
      const light = (col + row) % 2 === 0;
      const cls = ['sq', light ? 'light' : 'dark'];
      if (lastMove && (lastMove.from === sq || lastMove.to === sq)) cls.push('last');
      if ((drag?.from ?? selected) === sq) cls.push('sel');
      if (checkSquare === sq) cls.push('check');
      if (drag?.active && targets.has(sq)) {
        const hover = squareFromPoint(drag.x, drag.y);
        if (hover === sq) cls.push('hover');
      }
      const t = targets.get(sq);
      squares.push(
        <div key={sq} className={cls.join(' ')}>
          {settings.coords && col === 0 && <span className="coord rank">{sq[1]}</span>}
          {settings.coords && row === 7 && <span className="coord file">{sq[0]}</span>}
          {t && settings.showLegal && <span className={t.capture ? 'hint capture' : 'hint'} />}
        </div>
      );
    }
  }

  // Animación de la última jugada (y de la torre en el enroque)
  const animate = settings.animations && lastMove && skipAnimKey.current !== animKey;
  const anim = new Map<string, { dx: number; dy: number }>();
  if (animate && lastMove) {
    const a = sqToXY(lastMove.from, orientation);
    const b = sqToXY(lastMove.to, orientation);
    anim.set(lastMove.to, { dx: a.col - b.col, dy: a.row - b.row });
    const moved = chess.get(lastMove.to as Square);
    if (moved?.type === 'k' && Math.abs(FILES.indexOf(lastMove.from[0]) - FILES.indexOf(lastMove.to[0])) === 2) {
      const rank = lastMove.to[1];
      const kingSide = lastMove.to[0] === 'g';
      const rf = `${kingSide ? 'h' : 'a'}${rank}`;
      const rt = `${kingSide ? 'f' : 'd'}${rank}`;
      const ra = sqToXY(rf, orientation);
      const rb = sqToXY(rt, orientation);
      anim.set(rt, { dx: ra.col - rb.col, dy: ra.row - rb.row });
    }
  }

  const pieces = [];
  for (const rowArr of chess.board()) {
    for (const p of rowArr) {
      if (!p) continue;
      const { col, row } = sqToXY(p.square, orientation);
      const an = anim.get(p.square);
      const style: React.CSSProperties & Record<string, string> = {
        left: `${col * 12.5}%`,
        top: `${row * 12.5}%`,
      };
      if (an) {
        style['--dx'] = `${an.dx * 100}%`;
        style['--dy'] = `${an.dy * 100}%`;
      }
      const cls = ['piece'];
      if (an) cls.push('anim');
      if (drag?.active && drag.from === p.square) cls.push('ghosted');
      pieces.push(
        <div key={an ? `${p.square}-${animKey}` : `${p.square}${p.color}${p.type}`} className={cls.join(' ')} style={style}>
          <PieceSvg type={p.type} color={p.color} />
        </div>
      );
    }
  }

  const dragPiece = drag?.active ? chess.get(drag.from) : null;

  return (
    <div
      className={`board theme-${settings.theme}`}
      ref={boardRef}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={() => setDrag(null)}
      onContextMenu={(e) => e.preventDefault()}
    >
      <div className="squares">{squares}</div>
      {discreet.length > 0 && (
        <div className="discreet-marks" aria-hidden="true">
          {discreet.flatMap((m, i) =>
            (['from', 'to'] as const).map((kind) => {
              const { col, row } = sqToXY(m[kind], orientation);
              return <span key={`${i}-${kind}`} className={`dmark ${kind}`} style={{ left: `${col * 12.5}%`, top: `${row * 12.5}%` }} />;
            })
          )}
        </div>
      )}
      <div className="pieces">{pieces}</div>

      {arrows && arrows.length > 0 && (
        <svg className="arrows" viewBox="0 0 8 8" aria-hidden="true">
          <defs>
            {arrows.map((a, i) => (
              <marker key={i} id={`ah-${uid}-${i}`} markerWidth="3" markerHeight="3" refX="1.2" refY="1.5" orient="auto">
                <path d="M0,0 L3,1.5 L0,3 z" fill={a.color || '#15781b'} />
              </marker>
            ))}
          </defs>
          {arrows.map((a, i) => {
            const f = sqToXY(a.from, orientation);
            const t = sqToXY(a.to, orientation);
            const x1 = f.col + 0.5,
              y1 = f.row + 0.5;
            let x2 = t.col + 0.5,
              y2 = t.row + 0.5;
            const len = Math.hypot(x2 - x1, y2 - y1) || 1;
            x2 -= ((x2 - x1) / len) * 0.38;
            y2 -= ((y2 - y1) / len) * 0.38;
            return (
              <line
                key={i}
                x1={x1}
                y1={y1}
                x2={x2}
                y2={y2}
                stroke={a.color || '#15781b'}
                strokeWidth={0.17}
                strokeLinecap="round"
                opacity={a.opacity ?? 0.85}
                markerEnd={`url(#ah-${uid}-${i})`}
              />
            );
          })}
        </svg>
      )}

      {dragPiece && drag && (
        <div
          className="drag-ghost"
          style={{ width: drag.size * 1.15, height: drag.size * 1.15, left: drag.x - drag.size * 0.575, top: drag.y - drag.size * 0.7 }}
        >
          <PieceSvg type={dragPiece.type} color={dragPiece.color} />
        </div>
      )}

      {promo && (
        <div className="promo-overlay" onPointerDown={(e) => { e.stopPropagation(); setPromo(null); }}>
          {(() => {
            const { col, row } = sqToXY(promo.to, orientation);
            const fromTop = row === 0;
            return (
              <div
                className="promo-col"
                style={{ left: `${col * 12.5}%`, top: fromTop ? 0 : undefined, bottom: fromTop ? undefined : 0, flexDirection: fromTop ? 'column' : 'column-reverse' }}
              >
                {(['q', 'n', 'r', 'b'] as PieceSymbol[]).map((t) => (
                  <button
                    key={t}
                    className="promo-btn"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      const p = promo;
                      setPromo(null);
                      onMove({ from: p.from, to: p.to, promotion: t });
                    }}
                  >
                    <PieceSvg type={t} color={promo.color} />
                  </button>
                ))}
              </div>
            );
          })()}
        </div>
      )}
    </div>
  );
}
