// Chess Assistant: panel privado de análisis con Stockfish (sólo cuenta Diego).
// Se ejecuta íntegramente en este dispositivo; nada se envía al servidor ni al rival.
import { useEffect, useRef, useState } from 'react';
import type { Color } from 'chess.js';
import { StockfishEngine, evalToBar, formatEval, type EngineLine } from '../lib/engine';
import { PIECE_NAMES, colorName, pvToSan, uciToInfo } from '../lib/chessUtil';
import type { Arrow } from './Board';
import { Icon, Segmented, Toggle } from './ui';

interface Props {
  fen: string;
  /** Color del usuario en la partida (para resaltar si es su turno). */
  myColor?: Color | null;
  onArrows: (a: Arrow[]) => void;
  disabled?: boolean;
}

const ARROW_COLORS = ['#2e9e3a', '#2f7fd6', '#d68b2f'];

type DisplayMode = 'arrows' | 'discreet';
const DISPLAY_KEY = 'ca_assistant_display';
function loadDisplayMode(): DisplayMode {
  try {
    return localStorage.getItem(DISPLAY_KEY) === 'discreet' ? 'discreet' : 'arrows';
  } catch {
    return 'arrows';
  }
}

export default function AssistantPanel({ fen, myColor, onArrows, disabled }: Props) {
  const engineRef = useRef<StockfishEngine | null>(null);
  const requestRef = useRef(0);
  const [open, setOpen] = useState(true);
  const [depth, setDepth] = useState(16);
  const [multipv, setMultipv] = useState(3);
  const [auto, setAuto] = useState(true);
  const [showArrows, setShowArrows] = useState(true);
  const [displayMode, setDisplayModeState] = useState<DisplayMode>(loadDisplayMode);
  const setDisplayMode = (m: DisplayMode) => {
    setDisplayModeState(m);
    try {
      localStorage.setItem(DISPLAY_KEY, m);
    } catch {
      /* sin almacenamiento */
    }
  };
  const [lines, setLines] = useState<EngineLine[]>([]);
  const [analyzedFen, setAnalyzedFen] = useState('');
  const [thinking, setThinking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [onlyMyTurn, setOnlyMyTurn] = useState(false);

  useEffect(() => {
    const e = new StockfishEngine();
    engineRef.current = e;
    e.ready().catch((err) => setError(err.message));
    return () => {
      e.terminate();
      engineRef.current = null;
    };
  }, []);

  const turn = fen.split(' ')[1] as Color;
  const skip = disabled || (onlyMyTurn && myColor && turn !== myColor);

  function analyze() {
    const e = engineRef.current;
    if (!e || e.failed) return;
    const req = ++requestRef.current;
    setThinking(true);
    setLines([]);
    setAnalyzedFen(fen);
    const thisFen = fen;
    e.search(thisFen, `depth ${depth}`, {
      multipv,
      onInfo: (ls) => req === requestRef.current && setLines(ls),
    }).then((res) => {
      // Ignora resultados de una posición anterior que llegan tarde
      if (!res || req !== requestRef.current) return;
      if (res.lines.length) setLines(res.lines);
      setThinking(false);
    });
  }

  useEffect(() => {
    if (!open || !auto || skip) {
      if (skip) {
        requestRef.current++;
        engineRef.current?.stop();
        setThinking(false);
      }
      return;
    }
    analyze();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fen, depth, multipv, auto, open, skip]);

  // Indicadores en el tablero (sólo visibles en este dispositivo; nunca se envían al servidor)
  useEffect(() => {
    if (!open || !showArrows || analyzedFen !== fen || skip) return onArrows([]);
    if (displayMode === 'discreet') {
      // Mismos datos de Stockfish: casilla de origen y destino de la mejor jugada.
      const bestMove = lines.find((l) => l.multipv === 1 && l.pv[0])?.pv[0];
      return onArrows(bestMove ? [{ from: bestMove.slice(0, 2), to: bestMove.slice(2, 4), mode: 'discreet' }] : []);
    }
    onArrows(
      lines
        .filter((l) => l.pv[0])
        .slice(0, multipv)
        .map((l, i) => ({ from: l.pv[0].slice(0, 2), to: l.pv[0].slice(2, 4), color: ARROW_COLORS[i], opacity: i === 0 ? 0.9 : 0.6 }))
        .reverse()
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lines, showArrows, open, fen, analyzedFen, skip, displayMode]);

  const best = lines[0];
  const bar = evalToBar(best);
  const curDepth = Math.max(0, ...lines.map((l) => l.depth));
  const valid = analyzedFen === fen;

  return (
    <section className="assistant">
      <button className="as-head" onClick={() => setOpen(!open)}>
        <span className="as-title">
          <Icon name="bolt" size={18} /> Chess Assistant
        </span>
        <span className="as-badge">
          <Icon name="lock" size={13} /> Privado
        </span>
      </button>

      {open && (
        <div className="as-body">
          {error ? (
            <div className="error-box">{error}</div>
          ) : (
            <>
              <div className="as-eval">
                <div className="evalbar" title="Evaluación">
                  <div className="evalbar-w" style={{ width: `${bar * 100}%` }} />
                </div>
                <div className="as-evalnum">{valid && best ? formatEval(best) : '…'}</div>
              </div>
              <div className="muted small as-status">
                {skip
                  ? 'En pausa: esperando tu turno.'
                  : thinking
                    ? `Analizando… profundidad ${curDepth}/${depth}`
                    : valid && best
                      ? `Profundidad ${curDepth} · juegan ${colorName(turn).toLowerCase()}`
                      : 'Pulsa “Nueva recomendación”.'}
              </div>

              <ol className="as-lines">
                {valid &&
                  lines.map((l, i) => {
                    const info = uciToInfo(fen, l.pv[0]);
                    if (!info) return null;
                    const pv = pvToSan(fen, l.pv, 6);
                    return (
                      <li key={l.multipv} className="as-line">
                        <span className="as-dot" style={{ background: ARROW_COLORS[i] }} />
                        <div className="as-line-main">
                          <div className="as-move">
                            <b>{info.san}</b>
                            <span className="as-eval-chip">{formatEval(l)}</span>
                          </div>
                          <div className="small">
                            {PIECE_NAMES[info.piece]} de <b>{info.from}</b> a <b>{info.to}</b>
                            {info.captured ? ` (captura ${PIECE_NAMES[info.captured].toLowerCase()})` : ''}
                            {info.promotion ? ` · corona ${PIECE_NAMES[info.promotion].toLowerCase()}` : ''}
                          </div>
                          <div className="muted small as-pv">{pv.join(' ')}</div>
                        </div>
                      </li>
                    );
                  })}
              </ol>

              <div className="as-controls">
                <label className="slider-row">
                  <span>Profundidad: <b>{depth}</b></span>
                  <input type="range" min={6} max={24} value={depth} onChange={(e) => setDepth(Number(e.target.value))} />
                </label>
                <label className="slider-row">
                  <span>Recomendaciones: <b>{multipv}</b></span>
                  <input type="range" min={1} max={3} value={multipv} onChange={(e) => setMultipv(Number(e.target.value))} />
                </label>
                <Toggle checked={auto} onChange={setAuto} label="Analizar automáticamente" />
                <div className="as-display">
                  <span className="small">Visualización</span>
                  <Segmented
                    value={displayMode}
                    onChange={setDisplayMode}
                    options={[
                      { value: 'arrows', label: 'Flechas' },
                      { value: 'discreet', label: 'Discreto' },
                    ]}
                  />
                </div>
                <Toggle
                  checked={showArrows}
                  onChange={setShowArrows}
                  label={displayMode === 'arrows' ? 'Flechas en el tablero' : 'Contornos en el tablero'}
                />
                {myColor && <Toggle checked={onlyMyTurn} onChange={setOnlyMyTurn} label="Sólo en mi turno" />}
                <button className="btn primary full" onClick={analyze} disabled={!!skip}>
                  <Icon name="refresh" size={18} /> Nueva recomendación
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </section>
  );
}
